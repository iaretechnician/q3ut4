﻿using UnityEngine;
using UnityEngine.UI;
using Xsolla.Core;

namespace MarsFPSKit
{
    namespace Xsolla
    {
        public class Kit_XsollaLoginSocialButton : MonoBehaviour
        {
            /// <summary>
            /// Social provider this button is for
            /// </summary>
            public SocialProvider socialProvider;

            /// <summary>
            /// Our button
            /// </summary>
            public Button btn;
        }
    }
}