﻿using UnityEngine;
using UnityEngine.UI;
using TMPro;
using Xsolla.Core;
using Debug = UnityEngine.Debug;

namespace MarsFPSKit
{
    namespace Xsolla
    {
        public class Kit_XsollaWeaponEntry : MonoBehaviour
        {
            /// <summary>
            /// This displays our weapon's name
            /// </summary>
            public TextMeshProUGUI weaponName;
            /// <summary>
            /// Image that displays our weapon
            /// </summary>
            public Image weaponImage;
            /// <summary>
            /// Button that displays the weapon's state
            /// </summary>
            public TextMeshProUGUI weaponState;
            /// <summary>
            /// Price
            /// </summary>
            public TextMeshProUGUI price;
            /// <summary>
            /// Price if multiple currencies are available
            /// </summary>
            public TMP_Dropdown priceMultiple;
            /// <summary>
            /// If the price we selected is discounted, this will show the previous price
            /// </summary>
            public TextMeshProUGUI priceNonDiscounted;
            /// <summary>
            /// When does this rented item expire?
            /// </summary>
            public TextMeshProUGUI expiresAt;
            /// <summary>
            /// Button used to equip a weapon
            /// </summary>
            public Button useButton;
            /// <summary>
            /// Button used for buying a weapon
            /// </summary>
            public Button buyButton;
            /// <summary>
            /// Instead of a button, we display equipped
            /// </summary>
            public GameObject equipped;

            /// <summary>
            /// XSolla image url
            /// </summary>
            public string imageUrl;

            private void Start()
            {
                if (!string.IsNullOrEmpty(imageUrl))
                    ImageLoader.Instance.GetImageAsync(imageUrl, (_, sprite) =>
                    {
                        if (weaponImage)
                            weaponImage.sprite = sprite;
                    });
                else
                    Debug.LogError("Weapon has no image url.");
            }
        }
    }
}