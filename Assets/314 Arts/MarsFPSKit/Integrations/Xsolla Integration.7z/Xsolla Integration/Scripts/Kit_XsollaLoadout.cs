﻿using System;
using UnityEngine;
using Xsolla.Core;
using Xsolla.Store;
using MarsFPSKit.UI;
using TMPro;
using UnityEngine.UI;
using System.Collections.Generic;
using System.Linq;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using Xsolla.Login;
using Debug = UnityEngine.Debug;
using System.Collections;

namespace MarsFPSKit
{
    namespace Xsolla
    {
        /// <summary>
        /// Stores a loadout with item names
        /// </summary>
        public class XsollaLoadout
        {
            public string[] weapons;

            public string[] playerModel;
        }

        public class XsollaBuyEntry
        {
            /// <summary>
            /// Price with currency attached
            /// </summary>
            public string price;

            /// <summary>
            /// If this item (with this currency) is currently discounted, this will be assigned
            /// </summary>
            public string nonDiscountedPrice;

            /// <summary>
            /// Action for buying
            /// </summary>
            public UnityEvent buyAction;
        }

        /// <summary>
        /// Stores information for consumeables that will be consumed upon leaving the match/closing the game
        /// </summary>
        public class XsollaConsumeablesInUse
        {
            /// <summary>
            /// SKU of the consumeable
            /// </summary>
            public ConsumeItem item;
            /// <summary>
            /// Did we spawn since we equipped this item?
            /// </summary>
            public bool spawnedSinceEquip;
        }

        public class Kit_XsollaLoadout : Kit_LoadoutBase
        {
            /// <summary>
            /// Ingame menu
            /// </summary>
            private Kit_IngameMain main;

            private Kit_GameInformation game
            {
                get
                {
                    if (main) return main.gameInformation;
                    if (menuManager) return menuManager.game;

                    return null;
                }
            }

            /// <summary>
            /// Settings file
            /// </summary>
            public Kit_XsollaSettings settings;

            /// <summary>
            /// The loadout submenus
            /// </summary>
            [Header("Menu")]
            public UI.MenuScreen[] menuScreens;
            /// <summary>
            /// Value at which the concat started
            /// </summary>
            public int concatStart;
            /// <summary>
            /// Assigned in initialize
            /// </summary>
            private Kit_MenuManager menuManager;
            /// <summary>
            /// Canvas
            /// </summary>
            public Canvas canvas;

            /// <summary>
            /// Local loadout screen
            /// </summary>
            public int loadoutScreenLocalId;
            /// <summary>
            /// Master category screen
            /// </summary>
            public int masterCategoryScreenId;
            /// <summary>
            /// Weapon category screen id
            /// </summary>
            public int weaponCategoryScreenId;
            /// <summary>
            /// Player model selection screen id
            /// </summary>
            public int playerModelSelectionScreenId;

            [Header("UI")]
            /// <summary>
            /// Loadout layout in ui
            /// </summary>
            public RectTransform loadoutsGo;
            /// <summary>
            /// Loadout prefab
            /// </summary>
            public GameObject loadoutsPrefab;
            /// <summary>
            /// Back button for loadout state
            /// </summary>
            public Button loadoutsBackButton;
            /// <summary>
            /// Weapon category in ui
            /// </summary>
            public RectTransform weaponMasterCategoriesGo;
            /// <summary>
            /// Prefab for weapon categories
            /// </summary>
            public GameObject weaponMasterCategoryPrefab;
            /// <summary>
            /// Back Button for weapon master
            /// </summary>
            public Button weaponMasterBackButton;
            /// <summary>
            /// Weapon category in ui
            /// </summary>
            public RectTransform weaponCategoriesGo;
            /// <summary>
            /// Prefab for weapon categories
            /// </summary>
            public GameObject weaponCategoryPrefab;
            /// <summary>
            /// Layout for the weapon selection
            /// </summary>
            public RectTransform weaponSelectionGo;
            /// <summary>
            /// Prefab for the weapon selection
            /// </summary>
            public GameObject weaponSelectionPrefab;
            /// <summary>
            /// Back button
            /// </summary>
            public Button weaponSelectionBackButton;
            /// <summary>
            /// Active weapon selections
            /// </summary>
            public List<Kit_XsollaWeaponEntry> weaponSelectionActives = new List<Kit_XsollaWeaponEntry>();
            /// <summary>
            /// Layout for the team selection
            /// </summary>
            public RectTransform teamSelectionGo;
            /// <summary>
            /// Prefab for the team selection
            /// </summary>
            public GameObject teamSelectionPrefab;
            /// <summary>
            /// Layout for the playerModel selection
            /// </summary>
            public RectTransform playerModelSelectionGo;
            /// <summary>
            /// Prefab for the playerModel selection
            /// </summary>
            public GameObject playerModelSelectionPrefab;
            /// <summary>
            /// Back button
            /// </summary>
            public Button playerModelSelectionBackButton;
            /// <summary>
            /// Active playerModel selections
            /// </summary>
            public List<Kit_XsollaPlayerModelEntry> playerModelSelectionActives = new List<Kit_XsollaPlayerModelEntry>();

            /// <summary>
            /// Layout for weapon preview
            /// </summary>
            [Header("Preview")]
            public RectTransform loadoutSelectionWeaponPreviewGo;
            /// <summary>
            /// Prefab for weapon preview per class
            /// </summary>
            public GameObject loadoutSelectionWeaponPreviewPrefab;
            /// <summary>
            /// Entries for the weapon preview
            /// </summary>
            public List<Kit_XsollaWeaponPreview> loadoutSelectionWeaponPreviewActives = new List<Kit_XsollaWeaponPreview>();
            /// <summary>
            /// Layout for player model preview go
            /// </summary>
            public RectTransform loadoutSelectionPlayerModelPreviewGo;
            /// <summary>
            /// Prefab for player model selection
            /// </summary>
            public GameObject loadoutSelectionPlayerModelPreviewPrefab;
            /// <summary>
            /// Active entries for player model loadout preview
            /// </summary>
            public List<Kit_XsollaPlayerModelPreview> loadoutSelectionPlayerModelPreviewActives = new List<Kit_XsollaPlayerModelPreview>();

            /// <summary>
            /// Layout for weapon preview
            /// </summary>
            public RectTransform masterCategorySelectionWeaponPreviewGo;
            /// <summary>
            /// Prefab for weapon preview per class
            /// </summary>
            public GameObject masterCategorySelectionWeaponPreviewPrefab;
            /// <summary>
            /// Entries for the weapon preview
            /// </summary>
            public List<Kit_XsollaWeaponPreview> masterCategorySelectionWeaponPreviewActives = new List<Kit_XsollaWeaponPreview>();
            /// <summary>
            /// Layout for player model preview go
            /// </summary>
            public RectTransform masterCategorySelectionPlayerModelPreviewGo;
            /// <summary>
            /// Prefab for player model selection
            /// </summary>
            public GameObject masterCategorySelectionPlayerModelPreviewPrefab;
            /// <summary>
            /// Active entries for player model masterCategory preview
            /// </summary>
            public List<Kit_XsollaPlayerModelPreview> masterCategorySelectionPlayerModelPreviewActives = new List<Kit_XsollaPlayerModelPreview>();

            /// <summary>
            /// Go for the virtual currency list
            /// </summary>
            [Header("Virtual Currency")]
            public RectTransform virtualCurrencyListGo;
            /// <summary>
            /// Prefab for the virtual currency list
            /// </summary>
            public GameObject virtualCurrencyListPrefab;
            /// <summary>
            /// List of active virutal currency entries
            /// </summary>
            public List<Kit_XsollaVirtualCurrencyPreview> virtualCurrencyListActives = new List<Kit_XsollaVirtualCurrencyPreview>();
            /// <summary>
            /// ID of the virtual currency package menu
            /// </summary>
            public int virtualCurrencyPackageMenu = 4;
            /// <summary>
            /// Go for virtual currency package purchase
            /// </summary>
            public RectTransform virtualCurrencyPackageListGo;
            /// <summary>
            /// Prefab for virtual currency package purchase
            /// </summary>
            public GameObject virtualCurrencyPackageListPrefab;
            /// <summary>
            /// List of active packages
            /// </summary>
            public List<Kit_XsollaVirtualCurrencyEntry> virtualCurrencyPackageListActives = new List<Kit_XsollaVirtualCurrencyEntry>();

            /// <summary>
            /// The root of the coupon redeem process
            /// </summary>
            [Header("Coupon")]
            public GameObject couponRoot;
            /// <summary>
            /// The coupon code
            /// </summary>
            public TMP_InputField couponText;

            /// <summary>
            /// Root object for displaying what we received
            /// </summary>
            [Header("Coupon success screen")]
            public GameObject couponReceivedItemsRoot;
            /// <summary>
            /// The items will be displayed here
            /// </summary>
            public RectTransform couponReceivedItemsGo;
            /// <summary>
            /// Prefab for displaying what we received
            /// </summary>
            public GameObject couponReceivedItemsPrefab;
            /// <summary>
            /// List of active items
            /// </summary>
            public List<Kit_XsollaCouponReceivedItem> couponReceivedItemsActive = new List<Kit_XsollaCouponReceivedItem>();


            [Header("Bundle menu")]
            /// <summary>
            /// Screen ID for the bundle menu
            /// </summary>
            public int bundleMenuScreen = 5;
            /// <summary>
            /// Go for virtual currency package purchase
            /// </summary>
            public RectTransform bundleMenuGo;
            /// <summary>
            /// Prefab for virtual currency package purchase
            /// </summary>
            public GameObject bundleMenuPrefab;
            /// <summary>
            /// List of active packages
            /// </summary>
            public List<Kit_XsollaBundleEntry> bundleMenuActives = new List<Kit_XsollaBundleEntry>();
            /// <summary>
            /// The button that enable us to go to the bundle menu
            /// </summary>
            public Button bundleMenuButton;


            /// <summary>
            /// This screen displays a message over all other menus except waiting screen
            /// </summary>
            [Header("Message Screen")]
            public GameObject messageScreenRoot;
            /// <summary>
            /// Title for the message
            /// </summary>
            public TextMeshProUGUI messageScreenTitle;
            /// <summary>
            /// This displays the message
            /// </summary>
            public TextMeshProUGUI messageScreenText;

            /// <summary>
            /// This displays the logo animation
            /// </summary>
            [Header("Waiting screen")]
            public GameObject waitingScreen;

            /// <summary>
            /// Active loadouts
            /// </summary>
            private XsollaLoadout[] loadouts;

            #region Runtime Data
            /// <summary>
            /// Current loadout
            /// </summary>
            private int currentlySelectedLoadout;
            /// <summary>
            /// Store items retrieved from xsolla
            /// </summary>
            private StoreItems weaponsInStore;
            /// <summary>
            /// Store items for each team (player models)
            /// </summary>
            private StoreItems[] playerModelsInStore;
            /// <summary>
            /// Items in our xsolla inventory
            /// </summary>
            private InventoryItems inventoryItems;
            /// <summary>
            /// Ready booleans (information received)
            /// <para>0 = inventory received</para>
            /// <para>1 = weapons received</para>
            /// <para>2+ = teams received</para>
            /// </summary>
            private bool[] ready;
            /// <summary>
            /// This is called whenever the inventory is refreshsed
            /// </summary>
            private UnityEvent redrawAction = new UnityEvent();
            /// <summary>
            /// Once we receive the catalog, we use this to lookup sku to image url
            /// </summary>
            private Dictionary<string, string> imageUrlLookUp = new Dictionary<string, string>();
            /// <summary>
            /// Whenever something in our XSolla loadout is updated, we save a cached kit loadout.
            /// </summary>
            public static Loadout cachedKitLoadout;
            /// <summary>
            /// List of virtual currency packages
            /// </summary>
            private VirtualCurrencyPackages virtualCurrencyPackages;
            /// <summary>
            /// Used for the back button, the menu that we were in previously
            /// </summary>
            private int virtualCurrencyPreviousMenu;
            /// <summary>
            /// Stored subscription item information
            /// </summary>
            private SubscriptionItems subscriptionItems;
            /// <summary>
            /// Used for the back button, the menu that we were in previously
            /// </summary>
            private int bundleMenuPreviousMenu;
            /// <summary>
            /// Consumeables that we currently use
            /// </summary>
            private static List<XsollaConsumeablesInUse> consumeablesInUse = new List<XsollaConsumeablesInUse>();
            #endregion

            #region Unity Calls
            private void Awake()
            {
                if (menuScreens.Length > 0)
                {
                    menuManager = FindObjectOfType<Kit_MenuManager>();
                    main = FindObjectOfType<Kit_IngameMain>();

                    if (menuManager)
                    {
                        concatStart = menuManager.menuScreens.Length;
                        //Merge the lists
                        menuManager.menuScreens = menuManager.menuScreens.Concat(menuScreens).ToArray();
                        //Set our screen
                        menuScreenId = concatStart + loadoutScreenLocalId;
                    }

                    if (main)
                    {
                        concatStart = main.menuScreens.Length;
                        //Merge the lists
                        main.menuScreens = main.menuScreens.Concat(menuScreens).ToArray();
                        //Set our screen
                        menuScreenId = concatStart + loadoutScreenLocalId;
                    }
                }

                //Disable all the roots
                for (int i = 0; i < menuScreens.Length; i++)
                {
                    if (menuScreens[i].root)
                    {
                        //Disable
                        menuScreens[i].root.SetActive(false);
                    }
                    else
                    {
                        Debug.LogError("[Xsolla] Menu root at index " + i + " is not assigned.", this);
                    }
                }

                //Set initial state
                couponReceivedItemsRoot.SetActive(false);
                waitingScreen.SetActive(false);
                messageScreenRoot.SetActive(false);
                bundleMenuButton.gameObject.SetActive(false);
            }

            private void Update()
            {
                if (menuManager)
                {
                    canvas.gameObject.SetActiveOptimized(menuManager.currentScreen >= concatStart && menuManager.currentScreen < concatStart + menuScreens.Length);
                }

                if (main)
                {
                    canvas.gameObject.SetActiveOptimized(main.currentScreen >= concatStart && main.currentScreen < concatStart + menuScreens.Length);
                }
            }

            private void OnDestroy()
            {
                ConsumeConsumeables();
            }

            private void OnApplicationQuit()
            {
                ConsumeConsumeables();
            }
            #endregion

            #region Menu Calls
            /// <summary>
            /// Call for buttons
            /// </summary>
            /// <param name="newMenu"></param>
            public void ChangeMenuButton(int newMenu)
            {
                if (menuManager)
                {
                    menuManager.ChangeMenuButton(concatStart + newMenu);
                }
                if (main)
                {
                    main.ChangeMenuButton(concatStart + newMenu);
                }
            }
            #endregion

            public override void ForceClose()
            {
                if (menuManager)
                {
                    if (menuManager.currentScreen == menuScreenId)
                    {
                        menuManager.SwitchMenu(menuManager.mainScreen);
                    }
                }

                if (main)
                {
                    if (main.currentScreen == menuScreenId)
                    {
                        main.SwitchMenu(main.pauseMenu.pauseMenuId);
                    }
                }

                isOpen = false;
                Save();
            }

            public override Loadout GetCurrentLoadout()
            {
                return cachedKitLoadout;
            }

            /// <summary>
            /// Was the menu initialized once?
            /// </summary>
            private bool wasInitialized;

            public override void Initialize()
            {
                if (!wasInitialized)
                {
                    main = FindObjectOfType<Kit_IngameMain>();
                    menuManager = FindObjectOfType<UI.Kit_MenuManager>();

                    //Setup ready array
                    ready = new bool[3 + game.allPvpTeams.Length];

                    //Setup back button
                    if (menuManager)
                    {
                        loadoutsBackButton.onClick.AddListener(delegate
                        {
                            //Go back to main screen
                            menuManager.ChangeMenuButton(menuManager.mainScreen);
                            //Set state
                            isOpen = false;
                            //Save
                            Save();
                        });
                    }

                    if (main)
                    {
                        loadoutsBackButton.onClick.AddListener(delegate
                        {
                            //Go back to main screen
                            main.ChangeMenuButton(main.pauseMenu.pauseMenuId);
                            //Set state
                            isOpen = false;
                            //Save
                            Save();
                        });
                    }

                    //Get configured store
                    XsollaStore.Instance.GetGroupItems(XsollaSettings.StoreProjectId, "weapons", OnWeaponGroupItemsSuccess, OnWeaponGroupItemsError, null);
                    XsollaStore.Instance.GetInventoryItems(XsollaSettings.StoreProjectId, OnInventorySuccess, OnInventoryError);

                    //Get bundles
                    XsollaStore.Instance.GetBundles(XsollaSettings.StoreProjectId, OnBundleSuccess, OnBundleError);

                    //Get virtual currency
                    XsollaStore.Instance.GetVirtualCurrencyList(XsollaSettings.StoreProjectId, OnVirtualCurrencyListSuccess, OnVirtualCurrencyListError);
                    XsollaStore.Instance.GetVirtualCurrencyBalance(XsollaSettings.StoreProjectId, OnVirtualCurrencyBalanceSuccess, OnVirtualCurrencyBalanceError);

                    //Get subscriptions
                    XsollaStore.Instance.GetSubscriptions(XsollaSettings.StoreProjectId, OnSubscriptionsSuccess, OnSubscriptionsError);

                    //Create array for team files
                    playerModelsInStore = new StoreItems[game.allPvpTeams.Length];

                    //Get team configs
                    for (int i = 0; i < game.allPvpTeams.Length; i++)
                    {
                        int id = i;
                        XsollaStore.Instance.GetGroupItems(XsollaSettings.StoreProjectId, "playermodels_" + game.allPvpTeams[id].teamName, delegate (StoreItems s) { OnTeamGroupItemsSuccess(id, s); }, delegate (Error e) { OnTeamGroupItemsError(id, e); }, null);
                    }

                    //Setup loadouts
                    loadouts = new XsollaLoadout[settings.loadoutAmount];

                    for (int i = 0; i < loadouts.Length; i++)
                    {
                        //Create instance
                        loadouts[i] = new XsollaLoadout();

                        //Assign default weapons
                        loadouts[i].weapons = new string[settings.starterGear.Length];

                        //Copy starting gear
                        for (int o = 0; o < loadouts[i].weapons.Length; o++)
                        {
                            loadouts[i].weapons[o] = settings.starterGear[o];
                        }

                        //Copy starting team loadout
                        loadouts[i].playerModel = new string[game.allPvpTeams.Length];

                        for (int o = 0; o < settings.teamSettings.Length; o++)
                        {
                            loadouts[i].playerModel[o] = settings.teamSettings[o].startingSkin;
                        }

                        int id = i;

                        Button btn = CreateButton(loadoutsGo, loadoutsPrefab, "Loadout #" + (id + 1).ToString());

                        //Click delegate
                        btn.onClick.AddListener(delegate
                        {
                            //Set loadout
                            currentlySelectedLoadout = id;
                            //Update cached loadout
                            UpdateCachedKitLoadout();
                            //Update previews
                            LoadoutHover(currentlySelectedLoadout);
                            MasterCategoryPreview(currentlySelectedLoadout);
                            //Proceed to category
                            ChangeMenuButton(masterCategoryScreenId);
                        });

                        //Hover
                        EventTrigger trg = btn.gameObject.AddComponent<EventTrigger>();
                        EventTrigger.Entry hover = new EventTrigger.Entry();
                        hover.eventID = EventTriggerType.PointerEnter;

                        hover.callback.AddListener(delegate
                        {
                            LoadoutHover(id);
                        });

                        trg.triggers.Add(hover);
                    }

                    //Create Loadout Preview
                    for (int i = 0; i < game.allWeaponCategories.Length; i++)
                    {
                        GameObject go = Instantiate(loadoutSelectionWeaponPreviewPrefab, loadoutSelectionWeaponPreviewGo, false);
                        Kit_XsollaWeaponPreview prv = go.GetComponentInChildren<Kit_XsollaWeaponPreview>();
                        loadoutSelectionWeaponPreviewActives.Add(prv);
                    }

                    for (int i = 0; i < game.allPvpTeams.Length; i++)
                    {
                        GameObject go = Instantiate(loadoutSelectionPlayerModelPreviewPrefab, loadoutSelectionPlayerModelPreviewGo, false);
                        Kit_XsollaPlayerModelPreview prv = go.GetComponentInChildren<Kit_XsollaPlayerModelPreview>();
                        loadoutSelectionPlayerModelPreviewActives.Add(prv);
                    }

                    //Create masterCategory Preview
                    for (int i = 0; i < game.allWeaponCategories.Length; i++)
                    {
                        GameObject go = Instantiate(masterCategorySelectionWeaponPreviewPrefab, masterCategorySelectionWeaponPreviewGo, false);
                        Kit_XsollaWeaponPreview prv = go.GetComponentInChildren<Kit_XsollaWeaponPreview>();
                        masterCategorySelectionWeaponPreviewActives.Add(prv);
                    }

                    for (int i = 0; i < game.allPvpTeams.Length; i++)
                    {
                        GameObject go = Instantiate(masterCategorySelectionPlayerModelPreviewPrefab, masterCategorySelectionPlayerModelPreviewGo, false);
                        Kit_XsollaPlayerModelPreview prv = go.GetComponentInChildren<Kit_XsollaPlayerModelPreview>();
                        masterCategorySelectionPlayerModelPreviewActives.Add(prv);
                    }

                    LoadoutHover(0);
                    MasterCategoryPreview(0);

                    //Setup master categories
                    //For now weapons & player model. We do this via code so that we may add more categories in the future without touching the ui
                    CreateButton(weaponMasterCategoriesGo, weaponMasterCategoryPrefab, "Weapons").onClick.AddListener(delegate
                    {
                        //Redraw weapon display with first category
                        RedrawWeaponDisplay(0);
                        //Proceed
                        ChangeMenuButton(weaponCategoryScreenId);
                    });

                    CreateButton(weaponMasterCategoriesGo, weaponMasterCategoryPrefab, "Player Model").onClick.AddListener(delegate
                    {
                        //Redraw first player model
                        RedrawPlayerModelDisplay(0);
                        //Proceed
                        ChangeMenuButton(playerModelSelectionScreenId);
                    });

                    //Back button
                    weaponMasterBackButton.onClick.AddListener(delegate
                    {
                        ChangeMenuButton(loadoutScreenLocalId);
                    });

                    //Set weapon selection back button
                    weaponSelectionBackButton.onClick.AddListener(delegate
                    {
                        //Change menu
                        ChangeMenuButton(masterCategoryScreenId);
                    });

                    //Setup categories
                    for (int i = 0; i < game.allWeaponCategories.Length; i++)
                    {
                        int id = i;
                        CreateButton(weaponCategoriesGo, weaponCategoryPrefab, game.allWeaponCategories[id]).onClick.AddListener(delegate
                        {
                            //Redraw weapon display
                            RedrawWeaponDisplay(id);
                        });
                    }

                    //Setup team selection
                    for (int i = 0; i < game.allPvpTeams.Length; i++)
                    {
                        int id = i;
                        CreateButton(teamSelectionGo, teamSelectionPrefab, game.allPvpTeams[id].teamName).onClick.AddListener(delegate
                        {
                            //Pick other team
                            RedrawPlayerModelDisplay(id);
                        });
                    }

                    //Player model selection back button
                    playerModelSelectionBackButton.onClick.AddListener(delegate
                    {
                        //Go Back
                        ChangeMenuButton(masterCategoryScreenId);
                    });

                    //Update cached loadout
                    UpdateCachedKitLoadout();

                    //Load
                    Load();

                    //Store
                    wasInitialized = true;
                }
                else
                {
                    //Setup loadouts
                    loadouts = new XsollaLoadout[settings.loadoutAmount];

                    //Reset loadouts
                    for (int i = 0; i < loadouts.Length; i++)
                    {
                        //Create instance
                        loadouts[i] = new XsollaLoadout();

                        //Assign default weapons
                        loadouts[i].weapons = new string[settings.starterGear.Length];

                        //Copy starting gear
                        for (int o = 0; o < loadouts[i].weapons.Length; o++)
                        {
                            loadouts[i].weapons[o] = settings.starterGear[o];
                        }

                        //Copy starting team loadout
                        loadouts[i].playerModel = new string[game.allPvpTeams.Length];

                        for (int o = 0; o < settings.teamSettings.Length; o++)
                        {
                            loadouts[i].playerModel[o] = settings.teamSettings[o].startingSkin;
                        }
                    }

                    UpdateCachedKitLoadout();

                    //Reset inventory ready state
                    ready[0] = false;

                    //Just update inventory
                    XsollaStore.Instance.GetInventoryItems(XsollaSettings.StoreProjectId, OnInventorySuccess, OnInventoryError);
                    //Get subscriptions
                    XsollaStore.Instance.GetSubscriptions(XsollaSettings.StoreProjectId, OnSubscriptionsSuccess, OnSubscriptionsError);

                    //Load
                    Load();
                }
            }

            #region Subscriptions
            private void OnSubscriptionsError(Error obj)
            {
                Debug.LogError("[Xsolla] Subscriptions Error: " + obj.errorCode + " : " + obj.errorMessage);

                //This is required
                ready[2] = false;
            }

            private void OnSubscriptionsSuccess(SubscriptionItems obj)
            {
                Debug.Log("[Xsolla] Subscriptions Success!");

                //Store subscriptions
                subscriptionItems = obj;

                //Set ready bool
                ready[2] = true;
            }
            #endregion

            #region Virtual Currency
            private void OnVirtualCurrencyPackagesListError(Error obj)
            {
                Debug.LogError("[Xsolla] Virtual Currency Packages List Error: " + obj.errorCode + " : " + obj.errorMessage);
            }

            private void OnVirtualCurrencyPackagesListSuccess(VirtualCurrencyPackages obj)
            {
                Debug.Log("[Xsolla] Virtual Currency Packages List Success!");

                //Check if a currency can be bought and set the button accordingly
                for (int i = 0; i < virtualCurrencyListActives.Count; i++)
                {
                    int id = i;
                    bool foundAtLeastOnePackage = false;
                    for (int o = 0; o < obj.items.Count; o++)
                    {
                        //Not really optimal but its just run once
                        for (int j = 0; j < obj.items[o].content.Count; j++)
                        {
                            if (virtualCurrencyListActives[id].sku == obj.items[o].content[j].sku)
                            {
                                foundAtLeastOnePackage = true;
                            }
                        }
                    }

                    virtualCurrencyListActives[id].btn.interactable = foundAtLeastOnePackage;

                    if (foundAtLeastOnePackage)
                    {
                        virtualCurrencyListActives[id].btn.onClick.AddListener(delegate
                        {
                            VirtualCurrencyPackageMenu(virtualCurrencyListActives[id].sku);
                        });
                    }
                }

                //Store the list
                virtualCurrencyPackages = obj;
            }

            private void OnVirtualCurrencyBalanceError(Error obj)
            {
                Debug.LogError("[Xsolla] Virtual Currency Balance Error: " + obj.errorCode + " : " + obj.errorMessage);
            }

            private void OnVirtualCurrencyBalanceSuccess(VirtualCurrenciesBalance obj)
            {
                Debug.Log("[Xsolla] Virtual Currency Balance Success!");

                //Setup list if necessary
                if (virtualCurrencyListActives.Count == 0)
                {
                    for (int i = 0; i < obj.items.Length; i++)
                    {
                        int id = i;
                        GameObject go = Instantiate(virtualCurrencyListPrefab, virtualCurrencyListGo, false);
                        Kit_XsollaVirtualCurrencyPreview prv = go.GetComponent<Kit_XsollaVirtualCurrencyPreview>();
                        //Assume 0
                        prv.txt.text = obj.items[id].name + ": 0";
                        //At this point we dont know if we can buy it, assume we can't
                        prv.btn.interactable = false;
                        //Set sku
                        prv.sku = obj.items[id].sku;
                        //Add to list
                        virtualCurrencyListActives.Add(prv);
                    }
                }

                //Update list
                for (int i = 0; i < obj.items.Length; i++)
                {
                    int id = i;
                    Kit_XsollaVirtualCurrencyPreview prv = virtualCurrencyListActives[id];
                    //Set amount
                    prv.txt.text = obj.items[id].name + ": " + obj.items[id].amount;
                }
            }

            private void OnVirtualCurrencyListError(Error obj)
            {
                Debug.LogError("[Xsolla] Virtual Currency List Error: " + obj.errorCode + " : " + obj.errorMessage);
            }

            private void OnVirtualCurrencyListSuccess(VirtualCurrencyItems obj)
            {
                Debug.Log("[Xsolla] Virtual Currency List Success!");

                //Setup list if necessary
                if (virtualCurrencyListActives.Count == 0)
                {
                    for (int i = 0; i < obj.items.Length; i++)
                    {
                        int id = i;
                        GameObject go = Instantiate(virtualCurrencyListPrefab, virtualCurrencyListGo, false);
                        Kit_XsollaVirtualCurrencyPreview prv = go.GetComponent<Kit_XsollaVirtualCurrencyPreview>();
                        //Assume 0
                        prv.txt.text = obj.items[id].name + ": 0";
                        //At this point we dont know if we can buy it, assume we can't
                        prv.btn.interactable = false;
                        //Set sku
                        prv.sku = obj.items[id].sku;
                        //Add to list
                        virtualCurrencyListActives.Add(prv);
                    }
                }

                //Request the package list
                XsollaStore.Instance.GetVirtualCurrencyPackagesList(XsollaSettings.StoreProjectId, OnVirtualCurrencyPackagesListSuccess, OnVirtualCurrencyPackagesListError);
            }

            /// <summary>
            /// Switch to the package menu for the given virtual currency sku
            /// </summary>
            /// <param name="sku"></param>
            public void VirtualCurrencyPackageMenu(string sku)
            {
                //Store current menu
                virtualCurrencyPreviousMenu = menuManager.currentScreen;
                //Switch to our menu
                ChangeMenuButton(virtualCurrencyPackageMenu);

                //Clear old
                for (int i = 0; i < virtualCurrencyPackageListActives.Count; i++)
                {
                    Destroy(virtualCurrencyPackageListActives[i].gameObject);
                }
                virtualCurrencyPackageListActives = new List<Kit_XsollaVirtualCurrencyEntry>();

                //Redraw menu
                for (int i = 0; i < virtualCurrencyPackages.items.Count; i++)
                {
                    int id = i;
                    //As far as I know from the XSolla board, one package can only contain one currency. I don't really know why this is a list
                    if (virtualCurrencyPackages.items[id].content.Count > 0 && virtualCurrencyPackages.items[id].content[0].sku == sku)
                    {
                        GameObject go = Instantiate(virtualCurrencyPackageListPrefab, virtualCurrencyPackageListGo, false);
                        Kit_XsollaVirtualCurrencyEntry entry = go.GetComponent<Kit_XsollaVirtualCurrencyEntry>();
                        //Set price
                        if (virtualCurrencyPackages.items[id].price != null)
                        {
                            entry.price.text = virtualCurrencyPackages.items[id].price.amount + " " + virtualCurrencyPackages.items[id].price.currency;

                            if (!Mathf.Approximately(virtualCurrencyPackages.items[id].price.GetAmount(), virtualCurrencyPackages.items[id].price.GetAmountWithoutDiscount()))
                            {
                                entry.priceNonDiscounted.text = "<s>" + virtualCurrencyPackages.items[id].price.amount_without_discount + " " + virtualCurrencyPackages.items[id].price.currency + "</s>";
                                entry.priceNonDiscounted.gameObject.SetActive(true);
                            }
                            else
                            {
                                entry.priceNonDiscounted.gameObject.SetActive(false);
                            }

                            //Setup buy
                            entry.buyButton.onClick.AddListener(delegate
                            {
                                XsollaStore.Instance.ItemPurchase(XsollaSettings.StoreProjectId, virtualCurrencyPackages.items[id].sku, OnPurchaseSuccess, OnPurchaseError);
                                waitingScreen.SetActive(true);
                            });
                            entry.buyButton.gameObject.SetActive(true);
                        }
                        else
                        {
                            entry.price.gameObject.SetActive(false);
                            entry.priceNonDiscounted.gameObject.SetActive(false);
                            entry.buyButton.gameObject.SetActive(false);

                            Debug.LogWarning("[XSolla] Virtual Currency Package has no price.");
                        }

                        //Set name
                        entry.virtualCurrencyName.text = virtualCurrencyPackages.items[id].name;

                        //Set image
                        entry.imageUrl = virtualCurrencyPackages.items[id].image_url;

                        //Add to list
                        virtualCurrencyPackageListActives.Add(entry);
                    }
                }
            }

            /// <summary>
            /// Go to previous menu
            /// </summary>
            public void VirtualCurrencyPackageMenuBack()
            {
                //Call on menu directly as the stored variable is global
                menuManager.ChangeMenuButton(virtualCurrencyPreviousMenu);
            }
            #endregion

            #region Coupon
            public void CouponOpen()
            {
                couponText.text = "";
                couponRoot.SetActive(true);
            }

            public void CouponRedeem()
            {
                //Check if a code was entered
                if (!couponText.text.IsNullOrWhiteSpace())
                {
                    XsollaStore.Instance.RedeemCouponCode(XsollaSettings.StoreProjectId, new CouponCode { coupon_code = couponText.text }, OnCouponSuccess, OnCouponError);

                    //Enable waiting
                    waitingScreen.SetActive(true);
                }
            }

            public void CouponCancel()
            {
                //Reset text and close
                couponText.text = "";
                couponRoot.SetActive(false);
            }

            private void OnCouponError(Error obj)
            {
                Debug.LogError("[Xsolla] Coupon Error: " + obj.errorCode + " : " + obj.errorMessage);

                //Close waiting
                waitingScreen.SetActive(false);

                //Display message
                DisplayMessage("Error", obj.errorMessage);
            }

            private void OnCouponSuccess(CouponRedeemedItems obj)
            {
                Debug.Log("[Xsolla] Coupon Success: " + obj.items.ToString());

                //Close waiting
                waitingScreen.SetActive(false);

                //Close coupon menu
                couponRoot.SetActive(false);

                //Clear
                for (int i = 0; i < couponReceivedItemsActive.Count; i++)
                {
                    Destroy(couponReceivedItemsActive[i].gameObject);
                }
                couponReceivedItemsActive = new List<Kit_XsollaCouponReceivedItem>();

                //Setup new ones
                for (int i = 0; i < obj.items.Length; i++)
                {
                    GameObject go = Instantiate(couponReceivedItemsPrefab, couponReceivedItemsGo, false);
                    Kit_XsollaCouponReceivedItem item = go.GetComponent<Kit_XsollaCouponReceivedItem>();
                    item.imageUrl = obj.items[i].image_url;
                    item.title.text = obj.items[i].name;
                    item.description.text = obj.items[i].description;
                    //Add to list
                    couponReceivedItemsActive.Add(item);
                }

                //Show menu
                couponReceivedItemsRoot.SetActive(true);
            }
            #endregion

            #region Bundles
            private void OnBundleError(Error obj)
            {
                Debug.LogError("[Xsolla] Bundle Error: " + obj.errorCode + " : " + obj.errorMessage);

                //Dont enable the menu
                bundleMenuButton.gameObject.SetActive(false);
            }

            private void OnBundleSuccess(BundleItems obj)
            {
                Debug.Log("[Xsolla] Bundle Success: " + obj.items.ToString());

                //Clear
                for (int i = 0; i < bundleMenuActives.Count; i++)
                {
                    Destroy(bundleMenuActives[i].gameObject);
                }
                bundleMenuActives = new List<Kit_XsollaBundleEntry>();

                //Create new ones
                for (int i = 0; i < obj.items.Length; i++)
                {
                    int id = i;
                    GameObject go = Instantiate(bundleMenuPrefab, bundleMenuGo, false);
                    Kit_XsollaBundleEntry entry = go.GetComponent<Kit_XsollaBundleEntry>();
                    entry.imageUrl = obj.items[id].image_url;
                    entry.bundleName.text = obj.items[id].name;

                    List<XsollaBuyEntry> availableEntries = new List<XsollaBuyEntry>();

                    //Set price
                    if (obj.items[id].price != null)
                    {
                        XsollaBuyEntry buy = new XsollaBuyEntry();
                        buy.price = obj.items[id].price.amount + " " + obj.items[id].price.currency;

                        if (!Mathf.Approximately(obj.items[id].price.GetAmount(), obj.items[id].price.GetAmountWithoutDiscount()))
                        {
                            buy.nonDiscountedPrice = "<s>" + obj.items[id].price.amount_without_discount + " " + obj.items[id].price.currency + "</s>";
                        }

                        buy.buyAction = new UnityEvent();
                        buy.buyAction.AddListener(delegate
                        {
                            XsollaStore.Instance.ItemPurchase(XsollaSettings.StoreProjectId, obj.items[id].sku, OnPurchaseSuccess, OnPurchaseError);
                            waitingScreen.SetActive(true);
                        });

                        //Add to list
                        availableEntries.Add(buy);
                    }

                    for (int o = 0; o < obj.items[id].virtual_prices.Length; o++)
                    {
                        int od = o;
                        XsollaBuyEntry buy = new XsollaBuyEntry();
                        buy.price = obj.items[id].virtual_prices[od].amount + " " + obj.items[id].virtual_prices[od].sku;

                        if (!Mathf.Approximately(float.Parse(obj.items[id].virtual_prices[od].amount), float.Parse(obj.items[id].virtual_prices[od].amount_without_discount)))
                        {
                            buy.nonDiscountedPrice = "<s>" + obj.items[id].virtual_prices[od].amount_without_discount + " " + obj.items[id].virtual_prices[od].sku + "</s>";
                        }

                        buy.buyAction = new UnityEvent();
                        buy.buyAction.AddListener(delegate
                        {
                            XsollaStore.Instance.ItemPurchaseForVirtualCurrency(XsollaSettings.StoreProjectId, obj.items[id].sku, obj.items[id].virtual_prices[od].sku, OnPurchaseVirtualCurrencySuccess, OnPurchaseVirtualCurrencyError);
                            waitingScreen.SetActive(true);
                        });

                        //Add to list
                        availableEntries.Add(buy);
                    }

                    if (availableEntries.Count > 0)
                    {
                        if (availableEntries.Count > 1)
                        {
                            entry.price.gameObject.SetActive(false);
                            entry.priceMultiple.gameObject.SetActive(true);

                            //Setup the dropdown
                            entry.priceMultiple.ClearOptions();
                            List<string> options = new List<string>();

                            //Convert entries to options
                            for (int o = 0; o < availableEntries.Count; o++)
                            {
                                options.Add(availableEntries[o].price);
                            }

                            //Set to dropdown
                            entry.priceMultiple.AddOptions(options);

                            //Select #0
                            entry.priceMultiple.value = 0;

                            //Set #0 non discounted price
                            entry.priceNonDiscounted.text = availableEntries[0].nonDiscountedPrice;

                            //Update discount
                            entry.priceMultiple.onValueChanged.AddListener(delegate
                            {
                                entry.priceNonDiscounted.text = availableEntries[entry.priceMultiple.value].nonDiscountedPrice;
                            });

                            //Setup button callback
                            entry.buyButton.onClick.AddListener(delegate
                            {
                                availableEntries[entry.priceMultiple.value].buyAction.Invoke();
                            });
                        }
                        else
                        {
                            entry.price.gameObject.SetActive(true);
                            entry.priceMultiple.gameObject.SetActive(false);

                            entry.price.text = availableEntries[0].price;
                            entry.priceNonDiscounted.text = availableEntries[0].nonDiscountedPrice;

                            //Setup button callback
                            entry.buyButton.onClick.AddListener(delegate
                            {
                                availableEntries[0].buyAction.Invoke();
                            });
                        }
                    }
                    else
                    {
                        Debug.LogWarning("No purchase options available for bundle with sku: " + obj.items[id].sku);
                    }

                    //Add to list
                    bundleMenuActives.Add(entry);
                }

                bundleMenuButton.gameObject.SetActive(true);
            }

            public void BundleMenuOpen()
            {
                //Store current menu
                bundleMenuPreviousMenu = menuManager.currentScreen;
                //Switch to our menu
                ChangeMenuButton(bundleMenuScreen);
            }

            public void BundleMenuBack()
            {
                //Call on menu directly as the stored variable is global
                menuManager.ChangeMenuButton(bundleMenuPreviousMenu);
            }
            #endregion

            #region Helpers
            public Button CreateButton(RectTransform rectGo, GameObject prefab, string content)
            {
                //Create UI
                GameObject go = Instantiate(prefab, rectGo, false);
                //Text
                TextMeshProUGUI txt = go.GetComponentInChildren<TextMeshProUGUI>();
                txt.text = content;
                //Button
                Button btn = go.GetComponentInChildren<Button>();
                return btn;
            }

            public void UpdateCachedKitLoadout()
            {
                cachedKitLoadout = new Loadout();
                //Create weapons
                cachedKitLoadout.loadoutWeapons = new LoadoutWeapon[game.allWeaponCategories.Length];

                for (int i = 0; i < cachedKitLoadout.loadoutWeapons.Length; i++)
                {
                    int id = i;
                    cachedKitLoadout.loadoutWeapons[id] = new LoadoutWeapon();
                    cachedKitLoadout.loadoutWeapons[id].goesToSlot = id;
                    cachedKitLoadout.loadoutWeapons[id].weaponID = settings.storeWeaponIdToIngameWeaponId[loadouts[currentlySelectedLoadout].weapons[id]];

                    //Setup attachments to 0 until this shop supports buying attachments
                    cachedKitLoadout.loadoutWeapons[id].attachments = new int[0];

                    if (game.allWeapons[cachedKitLoadout.loadoutWeapons[id].weaponID].GetType() == typeof(Weapons.Kit_ModernWeaponScript))
                    {
                        Weapons.Kit_ModernWeaponScript wpn = game.allWeapons[cachedKitLoadout.loadoutWeapons[id].weaponID] as Weapons.Kit_ModernWeaponScript;

                        if (wpn)
                        {
                            cachedKitLoadout.loadoutWeapons[id].attachments = new int[wpn.attachmentSlots.Length];
                        }
                    }
                }

                cachedKitLoadout.teamLoadout = new TeamLoadout[game.allPvpTeams.Length];

                for (int i = 0; i < cachedKitLoadout.teamLoadout.Length; i++)
                {
                    int id = i;
                    cachedKitLoadout.teamLoadout[id] = new TeamLoadout();
                    cachedKitLoadout.teamLoadout[id].playerModelID = settings.teamSettings[id].storePlayerModelIdToIngamePlayerModelId[loadouts[currentlySelectedLoadout].playerModel[id]];

                    Kit_ThirdPersonPlayerModel pm = game.allPvpTeams[id].playerModels[cachedKitLoadout.teamLoadout[id].playerModelID].prefab.GetComponent<Kit_ThirdPersonPlayerModel>();

                    //Same as with attachments - store does not support player model customization in 1.0 because I'm low on time. Will be added later.
                    cachedKitLoadout.teamLoadout[id].playerModelCustomizations = new int[pm.customizationSlots.Length];
                }
            }

            public void LoadoutHover(int id)
            {
                for (int i = 0; i < loadouts[id].weapons.Length; i++)
                {
                    //Get weapon id
                    if (settings.storeWeaponIdToIngameWeaponId.Contains(loadouts[id].weapons[i]))
                    {
                        int weaponId = settings.storeWeaponIdToIngameWeaponId[loadouts[id].weapons[i]];
                        loadoutSelectionWeaponPreviewActives[i].img.sprite = game.allWeapons[weaponId].weaponPicture;
                        loadoutSelectionWeaponPreviewActives[i].txt.text = game.allWeapons[weaponId].weaponName;
                    }
                }

                for (int i = 0; i < loadouts[id].playerModel.Length; i++)
                {
                    //Get playerModel id
                    if (settings.teamSettings[i].storePlayerModelIdToIngamePlayerModelId.Contains(loadouts[id].playerModel[i]))
                    {
                        int playerModelId = settings.teamSettings[i].storePlayerModelIdToIngamePlayerModelId[loadouts[id].playerModel[i]];
                        //Set name
                        loadoutSelectionPlayerModelPreviewActives[i].txt.text = game.allPvpTeams[i].playerModels[playerModelId].displayName;

                        if (imageUrlLookUp.ContainsKey(loadouts[id].playerModel[i]))
                        {
                            //Get lookup
                            loadoutSelectionPlayerModelPreviewActives[i].imageUrl = imageUrlLookUp[loadouts[id].playerModel[i]];
                            //To-Do get image
                            loadoutSelectionPlayerModelPreviewActives[i].UpdateImage();
                        }
                    }
                }
            }

            public void MasterCategoryPreview(int id)
            {
                for (int i = 0; i < loadouts[id].weapons.Length; i++)
                {
                    //Get weapon id
                    if (settings.storeWeaponIdToIngameWeaponId.Contains(loadouts[id].weapons[i]))
                    {
                        int weaponId = settings.storeWeaponIdToIngameWeaponId[loadouts[id].weapons[i]];
                        masterCategorySelectionWeaponPreviewActives[i].img.sprite = game.allWeapons[weaponId].weaponPicture;
                        masterCategorySelectionWeaponPreviewActives[i].txt.text = game.allWeapons[weaponId].weaponName;
                    }
                }

                for (int i = 0; i < loadouts[id].playerModel.Length; i++)
                {
                    //Get playerModel id
                    if (settings.teamSettings[i].storePlayerModelIdToIngamePlayerModelId.Contains(loadouts[id].playerModel[i]))
                    {
                        int playerModelId = settings.teamSettings[i].storePlayerModelIdToIngamePlayerModelId[loadouts[id].playerModel[i]];
                        //Set name
                        masterCategorySelectionPlayerModelPreviewActives[i].txt.text = game.allPvpTeams[i].playerModels[playerModelId].displayName;
                        if (imageUrlLookUp.ContainsKey(loadouts[id].playerModel[i]))
                        {
                            //Get lookup
                            masterCategorySelectionPlayerModelPreviewActives[i].imageUrl = imageUrlLookUp[loadouts[id].playerModel[i]];
                            masterCategorySelectionPlayerModelPreviewActives[i].UpdateImage();
                        }
                    }
                }
            }
            #endregion

            private void OnInventoryError(Error obj)
            {
                Debug.LogError("[Xsolla] Inventory Error: " + obj.errorCode + " : " + obj.errorMessage);
            }

            private void OnInventorySuccess(InventoryItems obj)
            {
                Debug.Log("[Xsolla] Inventory Success!");

                //Set bool
                ready[0] = true;

                //Store items
                inventoryItems = obj;

                //Redraw
                redrawAction.Invoke();
            }

            private void OnWeaponGroupItemsError(Error obj)
            {
                Debug.LogError("[Xsolla] Weapon items could not be retrieved: " + obj.ToString());
            }

            private void OnWeaponGroupItemsSuccess(StoreItems obj)
            {
                //Set ready bool
                ready[1] = true;

                //First off verify correct xsolla item to ingame item setup
                for (int i = 0; i < obj.items.Length; i++)
                {
                    int id = i;
                    if (!settings.storeWeaponIdToIngameWeaponId.ContainsKey(obj.items[id].sku))
                    {
                        Debug.LogError("[Xsolla] Weapon " + obj.items[id].sku + " is not mapped");
                    }

                    if (!imageUrlLookUp.ContainsKey(obj.items[id].sku))
                    {
                        //Add to lookup table
                        imageUrlLookUp.Add(obj.items[id].sku, obj.items[id].image_url);

                        //Preload image
                        ImageLoader.Instance.GetImageAsync(obj.items[id].image_url, null);
                    }
                }

                //Store items
                weaponsInStore = obj;
            }

            private void OnTeamGroupItemsError(int team, Error obj)
            {
                Debug.LogError("[Xsolla] Team #" + team + " items could not be retrieved: " + obj.ToString());
            }

            private void OnTeamGroupItemsSuccess(int team, StoreItems obj)
            {
                //Set ready bool
                ready[3 + team] = true;

                //First off verify correct xsolla item to ingame item setup
                for (int i = 0; i < obj.items.Length; i++)
                {
                    int id = i;
                    if (!settings.teamSettings[team].storePlayerModelIdToIngamePlayerModelId.ContainsKey(obj.items[id].sku))
                    {
                        Debug.LogError("[Xsolla] Player Model " + obj.items[id].sku + " is not mapped");
                    }

                    if (!imageUrlLookUp.ContainsKey(obj.items[id].sku))
                    {
                        //Add to lookup table
                        imageUrlLookUp.Add(obj.items[id].sku, obj.items[id].image_url);

                        //Preload image
                        ImageLoader.Instance.GetImageAsync(obj.items[id].image_url, null);
                    }
                }

                //Store
                playerModelsInStore[team] = obj;
            }

            public override void Open()
            {
                //Check if ready
                for (int i = 0; i < ready.Length; i++)
                {
                    if (!ready[i]) return;
                }

                //Update previews
                LoadoutHover(0);
                MasterCategoryPreview(0);

                //Menu Manager go to given
                ChangeMenuButton(loadoutScreenLocalId);
            }

            public void RedrawWeaponDisplay(int slot)
            {
                //Reset redraw listeners
                redrawAction.RemoveAllListeners();
                //Add this
                redrawAction.AddListener(delegate { RedrawWeaponDisplay(slot); });

                //Clear list
                for (int i = 0; i < weaponSelectionActives.Count; i++)
                {
                    Destroy(weaponSelectionActives[i].gameObject);
                }
                weaponSelectionActives = new List<Kit_XsollaWeaponEntry>();

                //Go through list
                for (int i = 0; i < weaponsInStore.items.Length; i++)
                {
                    //Get weapon id
                    if (settings.storeWeaponIdToIngameWeaponId.Contains(weaponsInStore.items[i].sku))
                    {
                        int weaponId = settings.storeWeaponIdToIngameWeaponId[weaponsInStore.items[i].sku];
                        //Get category
                        if (game.allWeapons[weaponId].weaponType == game.allWeaponCategories[slot])
                        {
                            int id = i;
                            byte unlockState = GetWeaponState(weaponsInStore.items[id].sku);

                            if (unlockState != 5)
                            {
                                //Create entry
                                GameObject go = Instantiate(weaponSelectionPrefab, weaponSelectionGo, false);
                                //Get setting
                                Kit_XsollaWeaponEntry entry = go.GetComponent<Kit_XsollaWeaponEntry>();
                                entry.imageUrl = weaponsInStore.items[i].image_url;
                                entry.weaponName.text = weaponsInStore.items[i].name;

                                switch (unlockState)
                                {
                                    case 0:
                                        entry.equipped.SetActive(true);
                                        entry.useButton.gameObject.SetActive(false);
                                        entry.buyButton.gameObject.SetActive(false);

                                        entry.weaponState.text = "EQUIPPED";

                                        //No price
                                        entry.price.gameObject.SetActive(false);
                                        entry.priceMultiple.gameObject.SetActive(false);
                                        entry.priceNonDiscounted.gameObject.SetActive(false);

                                        //No rent
                                        entry.expiresAt.text = "";

                                        break;
                                    case 1:
                                        entry.equipped.SetActive(true); ;
                                        entry.useButton.gameObject.SetActive(false);
                                        entry.buyButton.gameObject.SetActive(false);

                                        entry.weaponState.text = "STARTING GEAR";

                                        //No price
                                        entry.price.gameObject.SetActive(false);
                                        entry.priceMultiple.gameObject.SetActive(false);
                                        entry.priceNonDiscounted.gameObject.SetActive(false);

                                        //No rent
                                        entry.expiresAt.text = "";

                                        break;
                                    case 2:
                                        entry.equipped.SetActive(false);
                                        entry.useButton.gameObject.SetActive(true);
                                        entry.buyButton.gameObject.SetActive(false);

                                        entry.weaponState.text = "STARTING GEAR";

                                        //No price
                                        entry.price.gameObject.SetActive(false);
                                        entry.priceMultiple.gameObject.SetActive(false);
                                        entry.priceNonDiscounted.gameObject.SetActive(false);

                                        //No rent
                                        entry.expiresAt.text = "";

                                        //Create callback
                                        entry.useButton.onClick.AddListener(delegate
                                        {
                                            //Check if previous sku wasn't used (if it was a consumeable)
                                            RemoveConsumeableFromUseIfUnusued(loadouts[currentlySelectedLoadout].weapons[slot]);

                                            //Set SKU
                                            loadouts[currentlySelectedLoadout].weapons[slot] = weaponsInStore.items[id].sku;
                                            //Update cached loadout
                                            UpdateCachedKitLoadout();
                                            //Update previews
                                            LoadoutHover(currentlySelectedLoadout);
                                            MasterCategoryPreview(currentlySelectedLoadout);
                                            //Redraw
                                            RedrawWeaponDisplay(slot);
                                        });
                                        break;
                                    case 3:
                                        entry.equipped.SetActive(false);
                                        entry.useButton.gameObject.SetActive(true);
                                        entry.buyButton.gameObject.SetActive(false);

                                        entry.weaponState.text = "BOUGHT";

                                        //No price
                                        entry.price.gameObject.SetActive(false);
                                        entry.priceMultiple.gameObject.SetActive(false);
                                        entry.priceNonDiscounted.gameObject.SetActive(false);

                                        //No rent
                                        entry.expiresAt.text = "";

                                        //Create callback
                                        entry.useButton.onClick.AddListener(delegate
                                        {
                                            //Check if previous sku wasn't used (if it was a consumeable)
                                            RemoveConsumeableFromUseIfUnusued(loadouts[currentlySelectedLoadout].weapons[slot]);

                                            //Set SKU
                                            loadouts[currentlySelectedLoadout].weapons[slot] = weaponsInStore.items[id].sku;
                                            //Update cached loadout
                                            UpdateCachedKitLoadout();
                                            //Update previews
                                            LoadoutHover(currentlySelectedLoadout);
                                            MasterCategoryPreview(currentlySelectedLoadout);
                                            //Redraw
                                            RedrawWeaponDisplay(slot);
                                        });
                                        break;
                                    case 4:
                                        entry.equipped.SetActive(false);
                                        entry.useButton.gameObject.SetActive(false);
                                        entry.buyButton.gameObject.SetActive(true);

                                        entry.weaponState.text = "AVAILABLE";

                                        //No rent
                                        entry.expiresAt.text = "";

                                        List<XsollaBuyEntry> availableEntries = new List<XsollaBuyEntry>();

                                        //Set price
                                        if (weaponsInStore.items[id].price != null)
                                        {
                                            XsollaBuyEntry buy = new XsollaBuyEntry();
                                            buy.price = weaponsInStore.items[id].price.amount + " " + weaponsInStore.items[id].price.currency;

                                            if (!Mathf.Approximately(weaponsInStore.items[id].price.GetAmount(), weaponsInStore.items[id].price.GetAmountWithoutDiscount()))
                                            {
                                                buy.nonDiscountedPrice = "<s>" + weaponsInStore.items[id].price.amount_without_discount + " " + weaponsInStore.items[id].price.currency + "</s>";
                                            }

                                            buy.buyAction = new UnityEvent();
                                            buy.buyAction.AddListener(delegate
                                            {
                                                XsollaStore.Instance.ItemPurchase(XsollaSettings.StoreProjectId, weaponsInStore.items[id].sku, OnPurchaseSuccess, OnPurchaseError);
                                                waitingScreen.SetActive(true);
                                            });

                                            //Add to list
                                            availableEntries.Add(buy);
                                        }

                                        for (int o = 0; o < weaponsInStore.items[id].virtual_prices.Length; o++)
                                        {
                                            int od = o;
                                            XsollaBuyEntry buy = new XsollaBuyEntry();
                                            buy.price = weaponsInStore.items[id].virtual_prices[od].amount + " " + weaponsInStore.items[id].virtual_prices[od].sku;

                                            if (!Mathf.Approximately(float.Parse(weaponsInStore.items[id].virtual_prices[od].amount), float.Parse(weaponsInStore.items[id].virtual_prices[od].amount_without_discount)))
                                            {
                                                buy.nonDiscountedPrice = "<s>" + weaponsInStore.items[id].virtual_prices[od].amount_without_discount + " " + weaponsInStore.items[id].virtual_prices[od].sku + "</s>";
                                            }

                                            buy.buyAction = new UnityEvent();
                                            buy.buyAction.AddListener(delegate
                                            {
                                                XsollaStore.Instance.ItemPurchaseForVirtualCurrency(XsollaSettings.StoreProjectId, weaponsInStore.items[id].sku, weaponsInStore.items[id].virtual_prices[od].sku, OnPurchaseVirtualCurrencySuccess, OnPurchaseVirtualCurrencyError);
                                                waitingScreen.SetActive(true);
                                            });

                                            //Add to list
                                            availableEntries.Add(buy);
                                        }

                                        if (availableEntries.Count > 0)
                                        {
                                            if (availableEntries.Count > 1)
                                            {
                                                entry.price.gameObject.SetActive(false);
                                                entry.priceMultiple.gameObject.SetActive(true);

                                                //Setup the dropdown
                                                entry.priceMultiple.ClearOptions();
                                                List<string> options = new List<string>();

                                                //Convert entries to options
                                                for (int o = 0; o < availableEntries.Count; o++)
                                                {
                                                    options.Add(availableEntries[o].price);
                                                }

                                                //Set to dropdown
                                                entry.priceMultiple.AddOptions(options);

                                                //Select #0
                                                entry.priceMultiple.value = 0;

                                                //Set #0 non discounted price
                                                entry.priceNonDiscounted.text = availableEntries[0].nonDiscountedPrice;

                                                //Update discount
                                                entry.priceMultiple.onValueChanged.AddListener(delegate
                                                {
                                                    entry.priceNonDiscounted.text = availableEntries[entry.priceMultiple.value].nonDiscountedPrice;
                                                });

                                                //Setup button callback
                                                entry.buyButton.onClick.AddListener(delegate
                                                {
                                                    availableEntries[entry.priceMultiple.value].buyAction.Invoke();
                                                });
                                            }
                                            else
                                            {
                                                entry.price.gameObject.SetActive(true);
                                                entry.priceMultiple.gameObject.SetActive(false);

                                                entry.price.text = availableEntries[0].price;
                                                entry.priceNonDiscounted.text = availableEntries[0].nonDiscountedPrice;

                                                //Setup button callback
                                                entry.buyButton.onClick.AddListener(delegate
                                                {
                                                    availableEntries[0].buyAction.Invoke();
                                                });
                                            }
                                        }
                                        else
                                        {
                                            Debug.LogWarning("No purchase options available for weapon with sku: " + weaponsInStore.items[id].sku);
                                        }
                                        break;
                                    case 6:
                                        entry.equipped.SetActive(false);
                                        entry.useButton.gameObject.SetActive(true);
                                        entry.buyButton.gameObject.SetActive(false);

                                        entry.weaponState.text = "RENTED";

                                        //No price
                                        entry.price.gameObject.SetActive(false);
                                        entry.priceMultiple.gameObject.SetActive(false);
                                        entry.priceNonDiscounted.gameObject.SetActive(false);

                                        //No rent
                                        entry.expiresAt.text = GetRemainingRentTime(weaponsInStore.items[id].sku);

                                        //Create callback
                                        entry.useButton.onClick.AddListener(delegate
                                        {
                                            //Check if previous sku wasn't used (if it was a consumeable)
                                            RemoveConsumeableFromUseIfUnusued(loadouts[currentlySelectedLoadout].weapons[slot]);

                                            //Set SKU
                                            loadouts[currentlySelectedLoadout].weapons[slot] = weaponsInStore.items[id].sku;
                                            //Update cached loadout
                                            UpdateCachedKitLoadout();
                                            //Update previews
                                            LoadoutHover(currentlySelectedLoadout);
                                            MasterCategoryPreview(currentlySelectedLoadout);
                                            //Redraw
                                            RedrawWeaponDisplay(slot);
                                        });
                                        break;
                                    case 7:
                                        entry.equipped.SetActive(false);
                                        entry.useButton.gameObject.SetActive(true);
                                        entry.buyButton.gameObject.SetActive(false);

                                        entry.weaponState.text = "CONSUMEABLE";

                                        //No price
                                        entry.price.gameObject.SetActive(false);
                                        entry.priceMultiple.gameObject.SetActive(false);
                                        entry.priceNonDiscounted.gameObject.SetActive(false);

                                        //No rent
                                        entry.expiresAt.text = "";

                                        //Create callback
                                        entry.useButton.onClick.AddListener(delegate
                                        {
                                            //Check if previous sku wasn't used (if it was a consumeable)
                                            RemoveConsumeableFromUseIfUnusued(loadouts[currentlySelectedLoadout].weapons[slot]);

                                            //Set SKU
                                            loadouts[currentlySelectedLoadout].weapons[slot] = weaponsInStore.items[id].sku;

                                            //Add to consumeable list
                                            AddConsumeableIfNotAddedYet(weaponsInStore.items[id].sku);

                                            //Update cached loadout
                                            UpdateCachedKitLoadout();
                                            //Update previews
                                            LoadoutHover(currentlySelectedLoadout);
                                            MasterCategoryPreview(currentlySelectedLoadout);
                                            //Redraw
                                            RedrawWeaponDisplay(slot);
                                        });
                                        break;
                                }

                                //Add to list
                                weaponSelectionActives.Add(entry);
                            }
                        }
                    }
                    else
                    {
                        Debug.LogError("[Xsolla] Weapon in store with SKU: " + weaponsInStore.items[i].sku + " is not mapped to an ingame weapon id");
                    }
                }
            }

            public void RedrawPlayerModelDisplay(int team)
            {
                //Reset redraw listeners
                redrawAction.RemoveAllListeners();
                //Add this
                redrawAction.AddListener(delegate { RedrawPlayerModelDisplay(team); });

                //Clear list
                for (int i = 0; i < playerModelSelectionActives.Count; i++)
                {
                    Destroy(playerModelSelectionActives[i].gameObject);
                }
                playerModelSelectionActives = new List<Kit_XsollaPlayerModelEntry>();

                //Go through list
                for (int i = 0; i < playerModelsInStore[team].items.Length; i++)
                {
                    //Get playerModel id
                    if (settings.teamSettings[team].storePlayerModelIdToIngamePlayerModelId.Contains(playerModelsInStore[team].items[i].sku))
                    {
                        int playerModelId = settings.teamSettings[team].storePlayerModelIdToIngamePlayerModelId[playerModelsInStore[team].items[i].sku];
                        int id = i;
                        byte unlockState = GetPlayerModelState(playerModelsInStore[team].items[id].sku, team);

                        if (unlockState != 5)
                        {
                            //Create entry
                            GameObject go = Instantiate(playerModelSelectionPrefab, playerModelSelectionGo, false);
                            //Get setting
                            Kit_XsollaPlayerModelEntry entry = go.GetComponent<Kit_XsollaPlayerModelEntry>();
                            entry.imageUrl = playerModelsInStore[team].items[i].image_url;
                            entry.playerModelName.text = game.allPvpTeams[team].playerModels[playerModelId].displayName;

                            switch (unlockState)
                            {
                                case 0:
                                    entry.equipped.SetActive(true);
                                    entry.useButton.gameObject.SetActive(false);
                                    entry.buyButton.gameObject.SetActive(false);

                                    entry.playerModelState.text = "EQUIPPED";

                                    //No price
                                    entry.price.gameObject.SetActive(false);
                                    entry.priceMultiple.gameObject.SetActive(false);
                                    entry.priceNonDiscounted.gameObject.SetActive(false);

                                    //No rent
                                    entry.expiresAt.text = "";

                                    break;
                                case 2:
                                    entry.equipped.SetActive(false);
                                    entry.useButton.gameObject.SetActive(true);
                                    entry.buyButton.gameObject.SetActive(false);

                                    entry.playerModelState.text = "STARTING SKIN";

                                    //No price
                                    entry.price.gameObject.SetActive(false);
                                    entry.priceMultiple.gameObject.SetActive(false);
                                    entry.priceNonDiscounted.gameObject.SetActive(false);

                                    //No rent
                                    entry.expiresAt.text = "";

                                    //Create callback
                                    entry.useButton.onClick.AddListener(delegate
                                    {
                                        //Check if previous sku wasn't used (if it was a consumeable)
                                        RemoveConsumeableFromUseIfUnusued(loadouts[currentlySelectedLoadout].playerModel[team]);

                                        //Set SKU
                                        loadouts[currentlySelectedLoadout].playerModel[team] = playerModelsInStore[team].items[id].sku;
                                        //Update cached loadout
                                        UpdateCachedKitLoadout();
                                        //Update previews
                                        LoadoutHover(currentlySelectedLoadout);
                                        MasterCategoryPreview(currentlySelectedLoadout);
                                        //Redraw
                                        RedrawPlayerModelDisplay(team);
                                    });
                                    break;
                                case 3:
                                    entry.equipped.SetActive(false);
                                    entry.useButton.gameObject.SetActive(true);
                                    entry.buyButton.gameObject.SetActive(false);

                                    entry.playerModelState.text = "BOUGHT";

                                    //No price
                                    entry.price.gameObject.SetActive(false);
                                    entry.priceMultiple.gameObject.SetActive(false);
                                    entry.priceNonDiscounted.gameObject.SetActive(false);

                                    //No rent
                                    entry.expiresAt.text = "";

                                    //Create callback
                                    entry.useButton.onClick.AddListener(delegate
                                    {
                                        //Check if previous sku wasn't used (if it was a consumeable)
                                        RemoveConsumeableFromUseIfUnusued(loadouts[currentlySelectedLoadout].playerModel[team]);

                                        //Set SKU
                                        loadouts[currentlySelectedLoadout].playerModel[team] = playerModelsInStore[team].items[id].sku;
                                        //Update cached loadout
                                        UpdateCachedKitLoadout();
                                        //Update previews
                                        LoadoutHover(currentlySelectedLoadout);
                                        MasterCategoryPreview(currentlySelectedLoadout);
                                        //Redraw
                                        RedrawPlayerModelDisplay(team);
                                    });
                                    break;
                                case 4:
                                    entry.equipped.SetActive(false);
                                    entry.useButton.gameObject.SetActive(false);
                                    entry.buyButton.gameObject.SetActive(true);

                                    entry.playerModelState.text = "AVAILABLE";

                                    //No rent
                                    entry.expiresAt.text = "";

                                    List<XsollaBuyEntry> availableEntries = new List<XsollaBuyEntry>();

                                    //Set price
                                    if (playerModelsInStore[team].items[id].price != null)
                                    {
                                        XsollaBuyEntry buy = new XsollaBuyEntry();
                                        buy.price = playerModelsInStore[team].items[id].price.amount + " " + playerModelsInStore[team].items[id].price.currency;

                                        if (!Mathf.Approximately(playerModelsInStore[team].items[id].price.GetAmount(), playerModelsInStore[team].items[id].price.GetAmountWithoutDiscount()))
                                        {
                                            buy.nonDiscountedPrice = "<s>" + playerModelsInStore[team].items[id].price.amount_without_discount + " " + playerModelsInStore[team].items[id].price.currency + "</s>";
                                        }

                                        buy.buyAction = new UnityEvent();
                                        buy.buyAction.AddListener(delegate
                                        {
                                            XsollaStore.Instance.ItemPurchase(XsollaSettings.StoreProjectId, playerModelsInStore[team].items[id].sku, OnPurchaseSuccess, OnPurchaseError);
                                            waitingScreen.SetActive(true);
                                        });

                                        //Add to list
                                        availableEntries.Add(buy);
                                    }

                                    for (int o = 0; o < playerModelsInStore[team].items[id].virtual_prices.Length; o++)
                                    {
                                        int od = o;
                                        XsollaBuyEntry buy = new XsollaBuyEntry();
                                        buy.price = playerModelsInStore[team].items[id].virtual_prices[od].amount + " " + playerModelsInStore[team].items[id].virtual_prices[od].sku;

                                        if (!Mathf.Approximately(float.Parse(playerModelsInStore[team].items[id].virtual_prices[od].amount), float.Parse(playerModelsInStore[team].items[id].virtual_prices[od].amount_without_discount)))
                                        {
                                            buy.nonDiscountedPrice = "<s>" + playerModelsInStore[team].items[id].virtual_prices[od].amount_without_discount + " " + playerModelsInStore[team].items[id].virtual_prices[od].sku + "</s>";
                                        }

                                        buy.buyAction = new UnityEvent();
                                        buy.buyAction.AddListener(delegate
                                        {
                                            XsollaStore.Instance.ItemPurchaseForVirtualCurrency(XsollaSettings.StoreProjectId, playerModelsInStore[team].items[id].sku, playerModelsInStore[team].items[id].virtual_prices[od].sku, OnPurchaseVirtualCurrencySuccess, OnPurchaseVirtualCurrencyError);
                                            waitingScreen.SetActive(true);
                                        });

                                        //Add to list
                                        availableEntries.Add(buy);
                                    }

                                    if (availableEntries.Count > 0)
                                    {
                                        if (availableEntries.Count > 1)
                                        {
                                            entry.price.gameObject.SetActive(false);
                                            entry.priceMultiple.gameObject.SetActive(true);

                                            //Setup the dropdown
                                            entry.priceMultiple.ClearOptions();
                                            List<string> options = new List<string>();

                                            //Convert entries to options
                                            for (int o = 0; o < availableEntries.Count; o++)
                                            {
                                                options.Add(availableEntries[o].price);
                                            }

                                            //Set to dropdown
                                            entry.priceMultiple.AddOptions(options);

                                            //Select #0
                                            entry.priceMultiple.value = 0;

                                            //Set #0 non discounted price
                                            entry.priceNonDiscounted.text = availableEntries[0].nonDiscountedPrice;

                                            //Update discount
                                            entry.priceMultiple.onValueChanged.AddListener(delegate
                                            {
                                                entry.priceNonDiscounted.text = availableEntries[entry.priceMultiple.value].nonDiscountedPrice;
                                            });

                                            //Setup button callback
                                            entry.buyButton.onClick.AddListener(delegate
                                            {
                                                availableEntries[entry.priceMultiple.value].buyAction.Invoke();
                                            });
                                        }
                                        else
                                        {
                                            entry.price.gameObject.SetActive(true);
                                            entry.priceMultiple.gameObject.SetActive(false);

                                            entry.price.text = availableEntries[0].price;
                                            entry.priceNonDiscounted.text = availableEntries[0].nonDiscountedPrice;

                                            //Setup button callback
                                            entry.buyButton.onClick.AddListener(delegate
                                            {
                                                availableEntries[0].buyAction.Invoke();
                                            });
                                        }
                                    }
                                    else
                                    {
                                        Debug.LogWarning("No purchase options available for player model with sku: " + playerModelsInStore[team].items[id].sku);
                                    }
                                    break;
                                case 6:
                                    entry.equipped.SetActive(false);
                                    entry.useButton.gameObject.SetActive(true);
                                    entry.buyButton.gameObject.SetActive(false);

                                    entry.playerModelState.text = "RENTED";

                                    //No price
                                    entry.price.gameObject.SetActive(false);
                                    entry.priceMultiple.gameObject.SetActive(false);
                                    entry.priceNonDiscounted.gameObject.SetActive(false);

                                    //Rent
                                    entry.expiresAt.text = GetRemainingRentTime(weaponsInStore.items[id].sku);

                                    //Create callback
                                    entry.useButton.onClick.AddListener(delegate
                                    {
                                        //Check if previous sku wasn't used (if it was a consumeable)
                                        RemoveConsumeableFromUseIfUnusued(loadouts[currentlySelectedLoadout].playerModel[team]);

                                        //Set SKU
                                        loadouts[currentlySelectedLoadout].playerModel[team] = playerModelsInStore[team].items[id].sku;
                                        //Update cached loadout
                                        UpdateCachedKitLoadout();
                                        //Update previews
                                        LoadoutHover(currentlySelectedLoadout);
                                        MasterCategoryPreview(currentlySelectedLoadout);
                                        //Redraw
                                        RedrawPlayerModelDisplay(team);
                                    });
                                    break;
                                case 7:
                                    entry.equipped.SetActive(false);
                                    entry.useButton.gameObject.SetActive(true);
                                    entry.buyButton.gameObject.SetActive(false);

                                    entry.playerModelState.text = "CONSUMEABLE";

                                    //No price
                                    entry.price.gameObject.SetActive(false);
                                    entry.priceMultiple.gameObject.SetActive(false);
                                    entry.priceNonDiscounted.gameObject.SetActive(false);

                                    //No rent
                                    entry.expiresAt.text = "";

                                    //Create callback
                                    entry.useButton.onClick.AddListener(delegate
                                    {
                                        //Check if previous sku wasn't used (if it was a consumeable)
                                        RemoveConsumeableFromUseIfUnusued(loadouts[currentlySelectedLoadout].playerModel[team]);

                                        //Set SKU
                                        loadouts[currentlySelectedLoadout].playerModel[team] = playerModelsInStore[team].items[id].sku;

                                        //Add to consumeable list
                                        AddConsumeableIfNotAddedYet(playerModelsInStore[team].items[id].sku);

                                        //Update cached loadout
                                        UpdateCachedKitLoadout();
                                        //Update previews
                                        LoadoutHover(currentlySelectedLoadout);
                                        MasterCategoryPreview(currentlySelectedLoadout);
                                        //Redraw
                                        RedrawPlayerModelDisplay(team);
                                    });
                                    break;
                            }

                            //Add to list
                            playerModelSelectionActives.Add(entry);
                        }
                    }
                    else
                    {
                        Debug.LogError("[Xsolla] Player Model in store with SKU: " + playerModelsInStore[team].items[i].sku + " is not mapped to an ingame Player Model id");
                    }
                }
            }

            private void OnPurchaseError(Error obj)
            {
                Debug.LogError("[Xsolla] Purchase error: " + obj.ToString());

                //Hide waiting screen
                waitingScreen.SetActive(false);
            }

            private void OnPurchaseSuccess(PurchaseData obj)
            {
                XsollaStore.Instance.OpenPurchaseUi(obj);
                OrderTracking.Instance.AddOrderForTracking(XsollaSettings.StoreProjectId, obj.order_id, OnOrderSuccess, OnOrderError);

                //Hide waiting screen
                waitingScreen.SetActive(false);
            }

            private void OnPurchaseVirtualCurrencyError(Error obj)
            {
                Debug.LogError("[Xsolla] Purchase w/ Virtual Currency error: " + obj.ToString());

                //Tell the user something went wrong
                DisplayMessage("Virtual Currency Error", obj.errorMessage);

                //Hide waiting screen
                waitingScreen.SetActive(false);
            }

            private void OnPurchaseVirtualCurrencySuccess(PurchaseData obj)
            {
                //Update our Inventory
                XsollaStore.Instance.GetInventoryItems(XsollaSettings.StoreProjectId, OnInventorySuccess, OnInventoryError);

                //Update virtual currency too
                XsollaStore.Instance.GetVirtualCurrencyBalance(XsollaSettings.StoreProjectId, OnVirtualCurrencyBalanceSuccess, OnVirtualCurrencyBalanceError);

                //Display message
                DisplayMessage("Virtual Currency purchase", "Success!");

                //Hide waiting screen
                waitingScreen.SetActive(false);
            }

            private void OnOrderSuccess()
            {
                Debug.Log("[Xsolla] Order success!");

                //Update our Inventory
                XsollaStore.Instance.GetInventoryItems(XsollaSettings.StoreProjectId, OnInventorySuccess, OnInventoryError);

                //Update virtual currency too
                XsollaStore.Instance.GetVirtualCurrencyBalance(XsollaSettings.StoreProjectId, OnVirtualCurrencyBalanceSuccess, OnVirtualCurrencyBalanceError);

                //Hide waiting screen
                waitingScreen.SetActive(false);
            }

            private void OnOrderError(Error obj)
            {
                Debug.LogError("[Xsolla] Order error: " + obj.ToString());

                //Hide waiting screen
                waitingScreen.SetActive(false);
            }

            public bool IsItemInInventoryAndValid(string sku)
            {
                if (inventoryItems != null)
                {
                    for (int i = 0; i < inventoryItems.items.Length; i++)
                    {
                        if (inventoryItems.items[i].sku == sku)
                        {
                            if (inventoryItems.items[i].IsSubscription())
                            {
                                //Check if it is still available
                                for (int o = 0; o < subscriptionItems.items.Length; o++)
                                {
                                    if (subscriptionItems.items[o].sku == sku)
                                    {
                                        if (subscriptionItems.items[o].Status == SubscriptionStatusType.Active)
                                        {
                                            //Only tell us we rented it if we are active with the subscription
                                            return true;
                                        }
                                    }
                                }
                            }
                            else if (inventoryItems.items[i].IsConsumable())
                            {
                                if (inventoryItems.items[i].quantity > 0)
                                {
                                    return true;
                                }
                            }
                            else
                            {
                                return true;
                            }
                        }
                    }
                }

                return false;
            }


            /// <summary>
            /// Gets a weapon state; 0 = equipped; 2 = starting gear; 3 = in inventory (non consumeable); 4 = available for purchase; 5 = not available; 6 = in inventory (nonrenewing subscription); 7 = in inventory (consumeable)
            /// </summary>
            /// <param name="sku"></param>
            /// <returns></returns>
            public byte GetWeaponState(string wpn)
            {
                if (loadouts[currentlySelectedLoadout].weapons.Contains(wpn))
                {
                    return 0;
                }

                if (settings.starterGear.Contains(wpn))
                {
                    return 2;
                }

                if (inventoryItems != null)
                {
                    for (int i = 0; i < inventoryItems.items.Length; i++)
                    {
                        if (inventoryItems.items[i].sku == wpn)
                        {
                            if (inventoryItems.items[i].IsSubscription())
                            {
                                //Check if it is still available
                                for (int o = 0; o < subscriptionItems.items.Length; o++)
                                {
                                    if (subscriptionItems.items[o].sku == wpn)
                                    {
                                        if (subscriptionItems.items[o].Status == SubscriptionStatusType.Active)
                                        {
                                            //Only tell us we rented it if we are active with the subscription
                                            return 6;
                                        }
                                    }
                                }
                            }
                            else if (inventoryItems.items[i].IsConsumable())
                            {
                                if (inventoryItems.items[i].quantity > 0)
                                {
                                    return 7;
                                }
                            }
                            else
                            {
                                return 3;
                            }
                        }
                    }
                }

                if (weaponsInStore != null)
                {
                    for (int i = 0; i < weaponsInStore.items.Length; i++)
                    {
                        if (weaponsInStore.items[i].sku == wpn)
                        {
                            return 4;
                        }
                    }
                }

                return 5;
            }

            /// <summary>
            /// Gets a player model state; 0 = equipped; 2 = starting gear; 3 = in inventory; 4 = available for purchase; 5 = not available; 6 = in inventory (nonrenewing subscription); 7 = in inventory (consumeable)
            /// </summary>
            /// <param name="sku"></param>
            /// <returns></returns>
            public byte GetPlayerModelState(string sku, int team)
            {
                if (loadouts[currentlySelectedLoadout].playerModel[team] == sku)
                {
                    return 0;
                }

                if (settings.teamSettings[team].startingSkin == sku)
                {
                    return 2;
                }

                if (inventoryItems != null)
                {
                    for (int i = 0; i < inventoryItems.items.Length; i++)
                    {
                        if (inventoryItems.items[i].sku == sku)
                        {
                            if (inventoryItems.items[i].IsSubscription())
                            {
                                //Check if it is still available
                                for (int o = 0; o < subscriptionItems.items.Length; o++)
                                {
                                    if (subscriptionItems.items[o].sku == sku)
                                    {
                                        if (subscriptionItems.items[o].Status == SubscriptionStatusType.Active)
                                        {
                                            //Only tell us we rented it if we are active with the subscription
                                            return 6;
                                        }
                                    }
                                }
                            }
                            else if (inventoryItems.items[i].IsConsumable())
                            {
                                if (inventoryItems.items[i].quantity > 0)
                                {
                                    return 7;
                                }
                            }
                            else
                            {
                                return 3;
                            }
                        }
                    }
                }

                if (playerModelsInStore[team] != null)
                {
                    for (int i = 0; i < playerModelsInStore[team].items.Length; i++)
                    {
                        if (playerModelsInStore[team].items[i].sku == sku)
                        {
                            return 4;
                        }
                    }
                }

                return 5;
            }

            private DateTime UnixTimeToDateTime(long unixTime)
            {
                DateTime dtDateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc);
                dtDateTime = dtDateTime.AddSeconds(unixTime).ToLocalTime();
                return dtDateTime;
            }

            /// <summary>
            /// Get remaining time for given sku to display it to the player
            /// </summary>
            /// <param name="sku"></param>
            /// <returns></returns>
            public string GetRemainingRentTime(string sku)
            {
                //Check if it is still available
                for (int o = 0; o < subscriptionItems.items.Length; o++)
                {
                    if (subscriptionItems.items[o].sku == sku)
                    {
                        if (subscriptionItems.items[o].Status == SubscriptionStatusType.Active)
                        {
                            var timeLeft = UnixTimeToDateTime((long)subscriptionItems.items[o].expired_at) - DateTime.Now;
                            if (timeLeft.TotalDays >= 30)
                                return $"{(int)(timeLeft.TotalDays / 30)} month{(timeLeft.TotalDays > 60 ? "s" : "")} remaining";
                            if (timeLeft.TotalDays > 1)
                                return $"{(uint)(timeLeft.TotalDays)} day{(timeLeft.TotalDays > 1 ? "s" : "")} remaining";
                            if (timeLeft.TotalHours > 1)
                                return $"{(uint)(timeLeft.TotalHours)} hour{(timeLeft.TotalHours > 1 ? "s" : "")} remaining";
                            if (timeLeft.TotalMinutes > 1)
                                return $"{(uint)(timeLeft.TotalMinutes)} minute{(timeLeft.TotalMinutes > 1 ? "s" : "")} remaining";
                            return $"{(uint)(timeLeft.TotalSeconds)} second{(timeLeft.TotalSeconds > 1 ? "s" : "")} remaining";
                        }
                    }
                }

                return "";
            }

            private void Load()
            {
                //Load loadouts
                List<string> attributes = new List<string>();
                for (int i = 0; i < settings.loadoutAmount; i++)
                {
                    attributes.Add("loadout_" + i);
                }
                attributes.Add("loadout_selected");
                XsollaLogin.Instance.GetUserAttributes(Token.Instance, XsollaSettings.StoreProjectId, UserAttributeType.CUSTOM, attributes, null, OnAttributeGetSuccess, OnAttributeGetError);
            }


            private void OnAttributeGetError(Error obj)
            {
                Debug.Log("[XSolla] Attribute get error: " + obj.ToString());
            }

            //This is pretty much loading
            private void OnAttributeGetSuccess(List<UserAttribute> obj)
            {
                if (obj.Count - 1 == settings.loadoutAmount)
                {
                    for (int i = 0; i < settings.loadoutAmount; i++)
                    {
                        loadouts[i] = JsonUtility.FromJson<XsollaLoadout>(obj[i].value);
                    }
                }

                if (obj.Count > 0) //Its null if the user signs in for the first time or hasn't modified their loadout yet
                {
                    //Get selected loadout
                    int.TryParse(obj[obj.Count - 1].value, out currentlySelectedLoadout);
                }

                StartCoroutine(ValidateLoadout());

                UpdateCachedKitLoadout();
            }

            /// <summary>
            /// Validates the loadout, checks for expired items
            /// </summary>
            private IEnumerator ValidateLoadout()
            {
                //Wait for inventory to arrive properly
                while (!ready[0]) yield return null;

                for (int i = 0; i < loadouts.Length; i++)
                {
                    int id = i;
                    for (int o = 0; o < loadouts[id].weapons.Length; o++)
                    {
                        int od = o;

                        if (!settings.storeWeaponIdToIngameWeaponId.Contains(loadouts[id].weapons[od]))
                        {
                            loadouts[id].weapons[od] = settings.starterGear[od];
                        }
                        else
                        {
                            if (!IsItemInInventoryAndValid(loadouts[id].weapons[od]))
                            {
                                loadouts[id].weapons[od] = settings.starterGear[od];
                            }
                        }
                    }

                    for (int o = 0; o < loadouts[id].playerModel.Length; o++)
                    {
                        int od = o;

                        if (!settings.teamSettings[od].storePlayerModelIdToIngamePlayerModelId.Contains(loadouts[id].playerModel[od]))
                        {
                            loadouts[id].playerModel[od] = settings.teamSettings[od].startingSkin;
                        }
                        else
                        {
                            if (!IsItemInInventoryAndValid(loadouts[id].playerModel[od]))
                            {
                                loadouts[id].playerModel[od] = settings.teamSettings[od].startingSkin;
                            }
                        }
                    }
                }

                //Update the cached kit loadout
                UpdateCachedKitLoadout();
            }

            public void Save()
            {
                List<UserAttribute> attributes = new List<UserAttribute>();
                for (int i = 0; i < loadouts.Length; i++)
                {
                    attributes.Add(new UserAttribute { key = "loadout_" + i, value = JsonUtility.ToJson(loadouts[i]) });
                }
                attributes.Add(new UserAttribute { key = "loadout_selected", value = currentlySelectedLoadout.ToString() });
                XsollaLogin.Instance.UpdateUserAttributes(Token.Instance.ToString(), XsollaSettings.StoreProjectId, attributes, OnAttributeSetSuccess, OnAttributeSetError);
            }

            private void OnAttributeSetError(Error obj)
            {
                Debug.Log("[XSolla] Loadout Attributes update error: " + obj.ToString());
            }

            private void OnAttributeSetSuccess()
            {
                Debug.Log("[XSolla] Loadout Attributes updated");
            }

            /// <summary>
            /// Displays the given message to the user
            /// </summary>
            /// <param name="msg"></param>
            private void DisplayMessage(string title, string msg)
            {
                messageScreenTitle.text = title;
                messageScreenText.text = msg;
                messageScreenRoot.SetActive(true);
            }

            #region Consumeable Helpers
            /// <summary>
            /// Removes the consumeable by given sku if it wasn't used yet
            /// </summary>
            /// <param name="sku"></param>
            private void RemoveConsumeableFromUseIfUnusued(string sku)
            {
                RemoveConsumeableFromUseIfUnusued(GetConsumeItem(sku));
            }

            /// <summary>
            /// Removes the consumeable by given sku if it wasn't used yet
            /// </summary>
            /// <param name="sku"></param>
            private void RemoveConsumeableFromUseIfUnusued(ConsumeItem item)
            {
                if (item == null) return;

                for (int i = 0; i < consumeablesInUse.Count; i++)
                {
                    if (consumeablesInUse[i].item.sku == item.sku)
                    {
                        if (!consumeablesInUse[i].spawnedSinceEquip)
                        {
                            consumeablesInUse.RemoveAt(i);
                        }

                        break;
                    }
                }
            }

            private void AddConsumeableIfNotAddedYet(string sku)
            {
                AddConsumeableIfNotAddedYet(GetConsumeItem(sku));
            }

            private void AddConsumeableIfNotAddedYet(ConsumeItem item)
            {
                if (item == null) return;

                for (int i = 0; i < consumeablesInUse.Count; i++)
                {
                    if (consumeablesInUse[i].item.sku == item.sku)
                    {
                        return;
                    }
                }

                //Create new entry
                XsollaConsumeablesInUse consumeableInUse = new XsollaConsumeablesInUse();
                consumeableInUse.item = item;
                consumeableInUse.spawnedSinceEquip = false;
                //Add to list
                consumeablesInUse.Add(consumeableInUse);
            }

            public override void LocalPlayerSpawned(Kit_PlayerBehaviour pb)
            {
                //Set used to true
                for (int i = 0; i < consumeablesInUse.Count; i++)
                {
                    consumeablesInUse[i].spawnedSinceEquip = true;
                }
            }

            private void ConsumeConsumeables()
            {
                for (int i = consumeablesInUse.Count - 1; i >= 0; i--)
                {
                    if (consumeablesInUse[i].spawnedSinceEquip)
                    {
                        XsollaStore.Instance.ConsumeInventoryItem(XsollaSettings.StoreProjectId, consumeablesInUse[i].item, OnConsumeItemSuccess, OnConsumeItemError);
                        consumeablesInUse.RemoveAt(i);
                    }
                }
            }

            public static void OnConsumeItemError(Error obj)
            {
                Debug.LogError("[Xsolla] Consume Item Error: " + obj.errorCode + " : " + obj.errorMessage);
            }

            public static void OnConsumeItemSuccess()
            {
                Debug.Log("[Xsolla] Consume Item Success");
            }

            /// <summary>
            /// Gets consume item based on given sku
            /// </summary>
            /// <param name="sku"></param>
            /// <returns></returns>
            private ConsumeItem GetConsumeItem(string sku)
            {
                for (int i = 0; i < inventoryItems.items.Length; i++)
                {
                    if (inventoryItems.items[i].sku == sku)
                    {
                        if (inventoryItems.items[i].IsConsumable())
                        {
                            ConsumeItem itm = new ConsumeItem { instance_id = inventoryItems.items[i].instance_id, sku = inventoryItems.items[i].sku, quantity = 1 };
                            return itm;
                        }
                    }
                }

                return null;
            }
            #endregion
        }
    }
}