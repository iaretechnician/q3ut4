﻿namespace MarsFPSKit
{
    namespace Xsolla
    {
        public interface Kit_XsollaILoginAuthorization : Kit_XsollaIStoreStringAction
        {
            void TryAuth(params object[] args);
        }
    }
}