﻿using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace MarsFPSKit
{
    namespace Xsolla
    {
        public class Kit_XsollaVirtualCurrencyPreview : MonoBehaviour
        {
            /// <summary>
            /// Button to buy this
            /// </summary>
            public Button btn;
            /// <summary>
            /// Text
            /// </summary>
            public TextMeshProUGUI txt;
            /// <summary>
            /// SKU of this currency
            /// </summary>
            public string sku;
        }
    }
}