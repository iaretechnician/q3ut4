﻿using UnityEngine;
using MarsFPSKit.UI;
using Xsolla.Login;
using Xsolla.Core;
using System.Collections.Generic;
using System;
using System.Linq;
using Debug = UnityEngine.Debug;

namespace MarsFPSKit
{
    namespace Xsolla
    {
        [CreateAssetMenu(menuName = "MarsFPSKit/Leveling/Xsolla")]
        public class Kit_XsollaLeveling : Kit_LevelingBase
        {
            [Header("Settings")]
            public int maxLevel = 20;

            /// <summary>
            /// How much xp do we need for the first level up (lvl 1 to lvl 2)
            /// </summary>
            public int xpNeededForLevelTwo = 500;
            /// <summary>
            /// How much xp do we need to jump from maxlevel-1 to maxlevel?
            /// </summary>
            public int xpNeededForMaxLevel = 20000;

            public int currentLevel = 1;
            public int currentXp;

            public int[] xpNeeded;

            public override void AddXp(Kit_IngameMain main, int xp)
            {
                currentXp += xp;
                RecalculateLevelWithLevelUp(main);
            }

            public override int GetLevel()
            {
                return currentLevel;
            }

            public override int GetMaxLevel()
            {
                return maxLevel;
            }

            public override float GetPercentageToNextLevel()
            {
                if (currentLevel >= maxLevel) return 1f;
                else
                {
                    return (float)currentXp / xpNeeded[Mathf.Clamp(currentLevel, 0, xpNeeded.Length - 1)];
                }
            }

            public override void Initialize(Kit_MenuManager menu)
            {
                //Calculate XP needed
                xpNeeded = new int[maxLevel - 1];
                for (int i = 0; i < maxLevel - 1; i++)
                {
                    xpNeeded[i] = Mathf.RoundToInt(Mathf.Lerp(xpNeededForLevelTwo, xpNeededForMaxLevel, (float)i / (maxLevel - 2)));
                }
                currentLevel = 1;
                currentXp = 0;
                //Load XP
                List<string> attributes = new List<string>();
                attributes.Add("xp");
                XsollaLogin.Instance.GetUserAttributes(Token.Instance, XsollaSettings.StoreProjectId, UserAttributeType.CUSTOM, attributes, null, OnAttributeGetSuccess, OnAttributeGetError);
            }

            private void OnAttributeGetError(Error obj)
            {
                Debug.Log("[XSolla] Leveling Attribute get error: " + obj.ToString());
            }

            private void OnAttributeGetSuccess(List<UserAttribute> obj)
            {
                UserAttribute attr = obj.Where(x => x.key == "xp").FirstOrDefault();

                if (attr != null)
                {
                    if (!int.TryParse(attr.value, out currentXp))
                    {
                        currentXp = 0;
                    }
                    RecalculateLevel();
                }

                Kit_MenuManager manager = FindObjectOfType<Kit_MenuManager>();

                if (manager)
                {
                    //Reinitialize it to update
                    manager.playerState.Initialize(manager);
                }
            }

            private void RecalculateLevel()
            {
                int newLvl = 0;

                for (int i = 0; i < xpNeeded.Length; i++)
                {
                    if (currentXp > xpNeeded[i]) newLvl++;
                    else break;
                }

                if (newLvl + 1 > currentLevel)
                {
                    Save();
                }

                currentLevel = newLvl + 1;
            }

            private void RecalculateLevelWithLevelUp(Kit_IngameMain main)
            {
                int newLvl = 0;

                for (int i = 0; i < xpNeeded.Length; i++)
                {
                    if (currentXp >= xpNeeded[i]) newLvl++;
                    else break;
                }

                if (newLvl + 1 > currentLevel)
                {
                    //Level up!
                    if (main.levelingUi)
                    {
                        main.levelingUi.DisplayLevelUp(newLvl + 1);
                    }
                    Save();
                }

                currentLevel = newLvl + 1;
            }

            public override void Save()
            {
                List<UserAttribute> attributes = new List<UserAttribute>();
                attributes.Add(new UserAttribute { key = "xp", value = currentXp.ToString() });
                XsollaLogin.Instance.UpdateUserAttributes(Token.Instance.ToString(), XsollaSettings.StoreProjectId, attributes, OnAttributeSetSuccess, OnAttributeSetError);
            }

            private void OnAttributeSetError(Error obj)
            {
                Debug.Log("[XSolla] Leveling Attributes update error: " + obj.ToString());
            }

            private void OnAttributeSetSuccess()
            {
                Debug.Log("[XSolla] Leveling Attributes updated");
            }
        }
    }
}