﻿using System;
using Xsolla.Core;

namespace MarsFPSKit
{
	namespace Xsolla
	{
		public interface Kit_XsollaIStoreStringAction
		{
			Action<string> OnSuccess { get; set; }
			Action<Error> OnError { get; set; }
		}
	}
}