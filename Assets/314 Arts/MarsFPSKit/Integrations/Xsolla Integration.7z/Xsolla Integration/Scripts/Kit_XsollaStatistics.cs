﻿using MarsFPSKit.UI;
using System.Collections.Generic;
using UnityEngine;
using Xsolla.Core;
using Xsolla.Login;
using Xsolla.Store;
using Debug = UnityEngine.Debug;

namespace MarsFPSKit
{
    namespace Xsolla
    {
        [CreateAssetMenu(menuName = "MarsFPSKit/Statistics/Xsolla")]
        /// <summary>
        /// Implements simple statistics with player prefs
        /// </summary>
        public class Kit_XsollaStatistics : Kit_StatisticsBase
        {
            /// <summary>
            /// Our accumulated kills
            /// </summary>
            public int kills;
            /// <summary>
            /// Our accumulated deaths
            /// </summary>
            public int deaths;
            /// <summary>
            /// Our accumulated assists
            /// </summary>
            public int assists;

            public override void OnAssist(Kit_IngameMain main)
            {
                assists++;
            }

            public override void OnDeath(Kit_IngameMain main, int weapon)
            {
                deaths++;
            }

            public override void OnDeath(Kit_IngameMain main, string weapon)
            {
                deaths++;
            }

            public override void OnKill(Kit_IngameMain main, int weapon)
            {
                kills++;
            }

            public override void OnKill(Kit_IngameMain main, string reason)
            {
                kills++;
            }

            public override void OnStart(Kit_MenuManager menu)
            {
                //Reset
                kills = 0;
                deaths = 0;
                assists = 0;

                //Load XP
                List<string> attributes = new List<string>();
                attributes.Add("kills");
                attributes.Add("deaths");
                attributes.Add("assists");
                XsollaLogin.Instance.GetUserAttributes(Token.Instance, XsollaSettings.StoreProjectId, UserAttributeType.CUSTOM, attributes, null, OnAttributeGetSuccess, OnAttributeGetError);
            }

            private void OnAttributeGetError(Error obj)
            {
                Debug.Log("[XSolla] Statistics Attribute get error: " + obj.ToString());
            }

            private void OnAttributeGetSuccess(List<UserAttribute> obj)
            {
                for (int i = 0; i < obj.Count; i++)
                {
                    switch (obj[i].key)
                    {
                        case "kills":
                            if (!int.TryParse(obj[i].value, out kills))
                            {
                                kills = 0;
                            }
                            break;

                        case "deaths":
                            if (!int.TryParse(obj[i].value, out deaths))
                            {
                                deaths = 0;
                            }
                            break;

                        case "assists":
                            if (!int.TryParse(obj[i].value, out assists))
                            {
                                assists = 0;
                            }
                            break;
                        default:

                            break;
                    }
                }

                Kit_MenuStatisticsForXsolla stats = FindObjectOfType<Kit_MenuStatisticsForXsolla>();

                if (stats)
                {
                    //Reinitialize it to update
                    stats.RedrawStatistics();
                }
            }

            public override void Save(Kit_IngameMain main)
            {
                List<UserAttribute> attributes = new List<UserAttribute>();
                attributes.Add(new UserAttribute { key = "kills", value = kills.ToString() });
                attributes.Add(new UserAttribute { key = "deaths", value = deaths.ToString() });
                attributes.Add(new UserAttribute { key = "assists", value = assists.ToString() });
                XsollaLogin.Instance.UpdateUserAttributes(Token.Instance.ToString(), XsollaSettings.StoreProjectId, attributes, OnAttributeSetSuccess, OnAttributeSetError);
            }

            public override void Save(Kit_MenuManager menu)
            {
                List<UserAttribute> attributes = new List<UserAttribute>();
                attributes.Add(new UserAttribute { key = "kills", value = kills.ToString() });
                attributes.Add(new UserAttribute { key = "deaths", value = deaths.ToString() });
                attributes.Add(new UserAttribute { key = "assists", value = assists.ToString() });
                if (XsollaLogin.Instance && XsollaStore.Instance)
                {
                    XsollaLogin.Instance.UpdateUserAttributes(Token.Instance.ToString(), XsollaSettings.StoreProjectId, attributes, OnAttributeSetSuccess, OnAttributeSetError);
                }
            }


            private void OnAttributeSetError(Error obj)
            {
                Debug.Log("[XSolla] Statistics Attributes update error: " + obj.ToString());
            }

            private void OnAttributeSetSuccess()
            {
                Debug.Log("[XSolla] Statistics Attributes updated");
            }
        }
    }
}