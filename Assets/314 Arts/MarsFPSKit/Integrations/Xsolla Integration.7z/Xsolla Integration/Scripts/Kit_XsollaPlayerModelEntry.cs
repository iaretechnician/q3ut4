﻿using UnityEngine;
using UnityEngine.UI;
using TMPro;
using Xsolla.Core;
using Debug = UnityEngine.Debug;

namespace MarsFPSKit
{
    namespace Xsolla
    {
        public class Kit_XsollaPlayerModelEntry : MonoBehaviour
        {
            /// <summary>
            /// This displays our playerModel's name
            /// </summary>
            public TextMeshProUGUI playerModelName;
            /// <summary>
            /// Image that displays our playerModel
            /// </summary>
            public Image playerModelImage;
            /// <summary>
            /// Button that displays the playerModel's state
            /// </summary>
            public TextMeshProUGUI playerModelState;
            /// <summary>
            /// Price
            /// </summary>
            public TextMeshProUGUI price;
            /// <summary>
            /// Price if multiple currencies are available
            /// </summary>
            public TMP_Dropdown priceMultiple;
            /// <summary>
            /// If the price we selected is discounted, this will show the previous price
            /// </summary>
            public TextMeshProUGUI priceNonDiscounted;
            /// <summary>
            /// Button used to equip a playerModel
            /// </summary>
            public Button useButton;
            /// <summary>
            /// Button used for buying a playerModel
            /// </summary>
            public Button buyButton;
            /// <summary>
            /// Instead of a button, we display equipped
            /// </summary>
            public GameObject equipped;
            /// <summary>
            /// When does this rented item expire?
            /// </summary>
            public TextMeshProUGUI expiresAt;
            /// <summary>
            /// XSolla image url
            /// </summary>
            public string imageUrl;

            private void Start()
            {
                if (!string.IsNullOrEmpty(imageUrl))
                    ImageLoader.Instance.GetImageAsync(imageUrl, (_, sprite) =>
                    {
                        if (playerModelImage)
                            playerModelImage.sprite = sprite;
                    });
                else
                    Debug.LogError("Player Model has no image url.");
            }
        }
    }
}